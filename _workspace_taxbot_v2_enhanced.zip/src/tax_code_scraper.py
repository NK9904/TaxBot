import asyncio
import aiohttp
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import hashlib
import json
from datetime import datetime

class TaxCodeScraper:
    """
    Scrapes and structures US IRS and Canadian CRA tax codes
    """
    
    def __init__(self):
        self.sources = {
            'us_federal': {
                'irs_code': 'https://www.law.cornell.edu/uscode/text/26',
                'irs_pubs': 'https://www.irs.gov/publications',
                'treasury_regs': 'https://www.ecfr.gov/current/title-26',
                'tax_court': 'https://www.ustaxcourt.gov/opinions.html'
            },
            'canadian_federal': {
                'income_tax_act': 'https://laws-lois.justice.gc.ca/eng/acts/I-3.3/',
                'cra_folios': 'https://www.canada.ca/en/revenue-agency/services/tax/technical-information/income-tax/income-tax-folios.html',
                'tax_court': 'https://www.tcc-cci.gc.ca/',
                'interpretations': 'https://www.canada.ca/en/revenue-agency/services/tax/technical-information/income-tax/technical-interpretations.html'
            }
        }
        
        self.scraped_data = []
        self.validation_checksums = {}
    
    async def scrape_all_sources(self):
        """
        Orchestrates scraping from all tax code sources
        """
        tasks = []
        
        # Federal sources
        for jurisdiction, sources in self.sources.items():
            for source_name, url in sources.items():
                if isinstance(url, str):
                    tasks.append(self.scrape_source(url, jurisdiction, source_name))
                elif isinstance(url, dict):
                    for sub_name, sub_url in url.items():
                        tasks.append(self.scrape_source(sub_url, jurisdiction, f"{source_name}_{sub_name}"))
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Process and structure results
        structured_data = self.structure_tax_data(results)
        
        # Validate completeness
        validation_report = self.validate_scraped_data(structured_data)
        
        return {
            'data': structured_data,
            'validation': validation_report,
            'timestamp': datetime.utcnow().isoformat()
        }
    
    async def scrape_source(self, url, jurisdiction, source_name):
        """
        Scrapes individual tax code source
        """
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    html = await response.text()
                    soup = BeautifulSoup(html, 'html.parser')
                    
                    # Extract structured data based on source type
                    if 'irs.gov' in url:
                        data = self.parse_irs_content(soup)
                    elif 'canada.ca' in url:
                        data = self.parse_cra_content(soup)
                    elif 'law.cornell.edu' in url:
                        data = self.parse_uscode_content(soup)
                    else:
                        data = self.parse_generic_legal_content(soup)
                    
                    return {
                        'jurisdiction': jurisdiction,
                        'source': source_name,
                        'url': url,
                        'content': data,
                        'checksum': hashlib.sha256(str(data).encode()).hexdigest(),
                        'scraped_at': datetime.utcnow().isoformat()
                    }
        except Exception as e:
            print(f"Error scraping {url}: {str(e)}")
            return None
    
    def parse_irs_content(self, soup):
        """
        Specialized parser for IRS content
        """
        sections = []
        
        # Extract sections, subsections, and provisions
        for section in soup.find_all(['h1', 'h2', 'h3', 'h4']):
            section_data = {
                'title': section.get_text().strip(),
                'level': section.name,
                'content': [],
                'provisions': []
            }
            
            # Get content until next heading
            current = section.next_sibling
            while current and current.name not in ['h1', 'h2', 'h3', 'h4']:
                if current.name == 'p':
                    section_data['content'].append(current.get_text().strip())
                elif current.name in ['ol', 'ul']:
                    provisions = [li.get_text().strip() for li in current.find_all('li')]
                    section_data['provisions'].extend(provisions)
                current = current.next_sibling
            
            sections.append(section_data)
        
        return sections
    
    def structure_tax_data(self, raw_data):
        """
        Structures scraped data into hierarchical format
        """
        structured = {
            'corporate_tax': {
                'us': {
                    'federal': {},
                    'state': {}
                },
                'canada': {
                    'federal': {},
                    'provincial': {}
                }
            },
            'personal_tax': {
                'us': {
                    'federal': {},
                    'state': {}
                },
                'canada': {
                    'federal': {},
                    'provincial': {}
                }
            },
            'cross_border': {},
            'tax_treaties': {},
            'case_law': {}
        }
        
        for item in raw_data:
            if item and item.get('content'):
                self.categorize_content(item, structured)
        
        return structured