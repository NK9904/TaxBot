import pytest
import asyncio
from decimal import Decimal
from datetime import datetime
from unittest.mock import Mock, patch

# Import our modules
from utils.accuracy_validation import AccuracyValidator
from data.tax_code_scraper import TaxCodeScraper
from models.model_training import TaxModelTrainer

class TestTaxBotAccuracy:
    """
    Comprehensive accuracy testing suite for TaxBot v2.0.
    This class tests all aspects of the accuracy validation system.
    """
    
    @pytest.fixture
    def accuracy_validator(self):
        """Fixture to provide an AccuracyValidator instance."""
        return AccuracyValidator()
    
    @pytest.fixture
    def valid_response(self):
        """Fixture to provide a valid response structure."""
        return {
            'answer': 'This is a valid tax advisory response with sufficient detail.',
            'confidence_score': 0.95,
            'jurisdiction': 'US',
            'category': 'corporate_tax',
            'calculation': {
                'income': 100000,
                'tax_rate': 0.21,
                'tax_amount': 21000
            }
        }
    
    @pytest.fixture
    def invalid_response(self):
        """Fixture to provide an invalid response structure."""
        return {
            'answer': 'Too short',
            'confidence_score': 'not_a_number',
            'jurisdiction': 'US'
            # Missing category field
        }
    
    def test_syntax_validation_valid(self, accuracy_validator, valid_response):
        """Test syntax validation with a valid response."""
        result = accuracy_validator.syntax_validation(
            "What is the corporate tax rate?",
            valid_response,
            {}
        )
        
        assert result['valid'] == True
        assert result['correction'] is None
    
    def test_syntax_validation_invalid(self, accuracy_validator, invalid_response):
        """Test syntax validation with an invalid response."""
        result = accuracy_validator.syntax_validation(
            "What is the corporate tax rate?",
            invalid_response,
            {}
        )
        
        assert result['valid'] == False
        assert 'correction' in result
        assert len(result['correction']) > 0
    
    def test_semantic_validation_valid(self, accuracy_validator, valid_response):
        """Test semantic validation with a valid response."""
        result = accuracy_validator.semantic_validation(
            "What is the corporate tax rate?",
            valid_response,
            {}
        )
        
        assert result['valid'] == True
        assert result['correction'] is None
    
    def test_semantic_validation_invalid_short(self, accuracy_validator):
        """Test semantic validation with a too short response."""
        short_response = {
            'answer': 'Short',
            'confidence_score': 0.95,
            'jurisdiction': 'US',
            'category': 'corporate_tax'
        }
        
        result = accuracy_validator.semantic_validation(
            "What is the corporate tax rate?",
            short_response,
            {}
        )
        
        assert result['valid'] == False
        assert 'correction' in result
        assert 'too short' in result['correction']
    
    def test_calculation_verification_valid(self, accuracy_validator, valid_response):
        """Test calculation verification with a valid response."""
        result = accuracy_validator.calculation_verification(
            "Calculate tax for $100,000 income",
            valid_response,
            {}
        )
        
        assert result['valid'] == True
        assert result['correction'] is None
    
    def test_calculation_verification_invalid(self, accuracy_validator):
        """Test calculation verification with an invalid calculation."""
        invalid_calc_response = {
            'answer': 'Based on calculations...',
            'confidence_score': 0.90,
            'jurisdiction': 'US',
            'category': 'corporate_tax',
            'calculation': {
                'income': 100000,
                'tax_rate': 0.21,
                'tax_amount': 20000  # Incorrect calculation (should be 21000)
            }
        }
        
        result = accuracy_validator.calculation_verification(
            "Calculate tax for $100,000 income",
            invalid_calc_response,
            {}
        )
        
        assert result['valid'] == False
        assert 'correction' in result
        assert 'Calculation error' in result['correction']
    
    def test_cross_reference_check_valid(self, accuracy_validator, valid_response):
        """Test cross-reference check with a valid response."""
        result = accuracy_validator.cross_reference_check(
            "What are US corporate tax rules?",
            valid_response,
            {}
        )
        
        assert result['valid'] == True
        assert result['correction'] is None
    
    def test_cross_reference_check_invalid_jurisdiction(self, accuracy_validator):
        """Test cross-reference check with an invalid jurisdiction."""
        invalid_jurisdiction_response = {
            'answer': 'UK tax rules apply...',
            'confidence_score': 0.85,
            'jurisdiction': 'UK',  # Invalid jurisdiction
            'category': 'corporate_tax'
        }
        
        result = accuracy_validator.cross_reference_check(
            "What are UK corporate tax rules?",
            invalid_jurisdiction_response,
            {}
        )
        
        assert result['valid'] == False
        assert 'correction' in result
        assert 'Unsupported jurisdiction' in result['correction']
    
    def test_expert_review_flag_low_confidence(self, accuracy_validator):
        """Test expert review flag with low confidence response."""
        low_confidence_response = {
            'answer': 'This is a complex tax situation...',
            'confidence_score': 0.65,  # Below threshold
            'jurisdiction': 'US',
            'category': 'corporate_tax'
        }
        
        result = accuracy_validator.expert_review_flag(
            "What about complex international tax scenarios?",
            low_confidence_response,
            {}
        )
        
        assert result['valid'] == True  # Still valid, just needs review
        assert result['requires_expert_review'] == True
        assert 'low confidence' in result['correction']
    
    def test_expert_review_flag_complex_keywords(self, accuracy_validator):
        """Test expert review flag with complexity keywords."""
        complex_response = {
            'answer': 'This depends on several factors and varies by circumstances...',
            'confidence_score': 0.90,
            'jurisdiction': 'US',
            'category': 'corporate_tax'
        }
        
        result = accuracy_validator.expert_review_flag(
            "What about complex international tax scenarios?",
            complex_response,
            {}
        )
        
        assert result['valid'] == True  # Still valid, just needs review
        assert result['requires_expert_review'] == True
        assert 'complexity keywords' in result['correction']
    
    def test_full_validation_process(self, accuracy_validator, valid_response):
        """Test the full validation process."""
        result = accuracy_validator.validate_response(
            "What is the corporate tax rate for $100,000 income?",
            valid_response,
            {}
        )
        
        assert result['is_valid'] == True
        assert result['confidence_score'] >= 0.8  # Should be high for valid response
        assert len(result['validation_details']) == 5  # All validation layers should be present
        assert result['corrections_needed'] == []  # No corrections needed for valid response
    
    def test_accuracy_report_generation(self, accuracy_validator, valid_response):
        """Test accuracy report generation."""
        # Run a few validations first
        accuracy_validator.validate_response(
            "Test query 1",
            valid_response,
            {}
        )
        
        accuracy_validator.validate_response(
            "Test query 2",
            {
                'answer': 'Too short',
                'confidence_score': 0.5,
                'jurisdiction': 'US',
                'category': 'corporate_tax'
            },
            {}
        )
        
        report = accuracy_validator.get_accuracy_report()
        
        assert report['total_validations'] == 2
        assert 'accuracy_rate' in report
        assert 'layer_statistics' in report
        assert len(report['layer_statistics']) == 5  # All validation layers should have stats

class TestTaxCodeScraper:
    """
    Test suite for the TaxCodeScraper class.
    """
    
    @pytest.fixture
    def scraper(self):
        """Fixture to provide a TaxCodeScraper instance."""
        return TaxCodeScraper()
    
    def test_scraper_initialization(self, scraper):
        """Test that scraper initializes correctly."""
        assert scraper.sources is not None
        assert isinstance(scraper.sources, dict)
        assert len(scraper.sources) > 0
    
    def test_structure_tax_data(self, scraper):
        """Test that tax data is structured correctly."""
        raw_data = [
            {
                'jurisdiction': 'us_federal',
                'source': 'irs_code',
                'content': [{'title': 'Section 1', 'level': 'h2', 'content': ['Content 1']}],
                'checksum': 'abc123',
                'scraped_at': datetime.utcnow().isoformat()
            }
        ]
        
        structured_data = scraper.structure_tax_data(raw_data)
        
        assert 'corporate_tax' in structured_data
        assert 'personal_tax' in structured_data
        assert 'cross_border' in structured_data
        assert 'tax_treaties' in structured_data
        assert 'case_law' in structured_data

class TestModelTrainer:
    """
    Test suite for the TaxModelTrainer class.
    """
    
    @pytest.fixture
    def trainer(self):
        """Fixture to provide a TaxModelTrainer instance."""
        return TaxModelTrainer()
    
    def test_data_quality_validation(self, trainer):
        """Test data quality validation."""
        good_data = [{'field1': 'value1', 'field2': 'value2'}]
        bad_data = []
        
        good_score = trainer.validate_data_quality(good_data)
        bad_score = trainer.validate_data_quality(bad_data)
        
        assert good_score == 1.0
        assert bad_score == 0.0
    
    def test_qa_pair_generation(self, trainer):
        """Test QA pair generation."""
        mock_data = {
            'corporate_tax': {
                'us': {
                    'federal': {
                        'irs_code': [
                            {
                                'title': 'Income Tax Provisions',
                                'content': ['Section content about income tax']
                            }
                        ]
                    }
                }
            }
        }
        
        qa_pairs = trainer.generate_qa_pairs(mock_data)
        
        assert isinstance(qa_pairs, list)
        if len(qa_pairs) > 0:
            assert 'question' in qa_pairs[0]
            assert 'answer' in qa_pairs[0]
            assert 'jurisdiction' in qa_pairs[0]

if __name__ == "__main__":
    pytest.main([__file__])