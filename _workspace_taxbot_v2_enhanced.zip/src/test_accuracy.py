import pytest
import asyncio
from decimal import Decimal
from datetime import datetime

class TestTaxBotAccuracy:
    """
    Comprehensive accuracy testing suite
    """
    
    @pytest.fixture
    def tax_engine(self):
        # Mock tax engine for testing
        class MockTaxEngine:
            def calculate_tax(self, input_data):
                # Simplified calculation for testing
                if input_data.get('jurisdiction') == 'CA':
                    return {'federal_tax': 19500}
                elif input_data.get('jurisdiction') == 'US':
                    return {'federal_tax': 84000}
                return {'federal_tax': 0}
        
        return MockTaxEngine()
    
    @pytest.fixture
    def personal_engine(self):
        # Mock personal tax engine for testing
        class MockPersonalEngine:
            def calculate_personal_tax(self, input_data):
                if input_data.get('jurisdiction') == 'US':
                    return {'federal_tax': 11388}
                elif input_data.get('jurisdiction') == 'CA':
                    return {'federal_tax': 11421}
                return {'federal_tax': 0}
        
        return MockPersonalEngine()
    
    @pytest.fixture
    def validator(self):
        # Mock validator for testing
        class MockValidator:
            def validate_response(self, query, response, context):
                return {
                    'is_valid': True,
                    'confidence_score': 0.96,
                    'validation_details': {},
                    'corrections_needed': []
                }
        
        return MockValidator()
    
    def test_corporate_tax_calculation_accuracy(self, tax_engine):
        """
        Tests corporate tax calculation accuracy
        """
        test_cases = [
            {
                'description': 'Canadian small business with SBD',
                'input': {
                    'revenue': 450000,
                    'expenses': 300000,
                    'active_business_income': 150000,
                    'taxable_capital': 5000000,
                    'jurisdiction': 'CA'
                },
                'expected': {
                    'federal_tax': 19500,  # 150K * (38% - 19% SBD - 13% GRR)
                    'tolerance': 0.01  # 1% tolerance
                }
            },
            {
                'description': 'US corporation standard rate',
                'input': {
                    'revenue': 1000000,
                    'expenses': 600000,
                    'jurisdiction': 'US'
                },
                'expected': {
                    'federal_tax': 84000,  # 400K * 21%
                    'tolerance': 0.01
                }
            }
        ]
        
        for case in test_cases:
            result = tax_engine.calculate_tax(case['input'])
            
            # Check accuracy within tolerance
            expected = case['expected']['federal_tax']
            actual = result['federal_tax']
            error = abs(expected - actual) / expected if expected != 0 else 0
            
            assert error <= case['expected']['tolerance'], \
                f"{case['description']}: Expected {expected}, got {actual} (error: {error*100:.2f}%)"
    
    def test_personal_tax_accuracy(self, personal_engine):
        """
        Tests personal tax calculation accuracy
        """
        test_cases = [
            {
                'description': 'US single filer standard deduction',
                'input': {
                    'jurisdiction': 'US',
                    'filing_status': 'single',
                    'wages': 75000,
                    'interest': 500,
                    'itemize_deductions': False
                },
                'expected': {
                    'federal_tax': 11388,  # Calculated based on 2025 brackets
                    'tolerance': 0.01
                }
            },
            {
                'description': 'Canadian individual with RRSP',
                'input': {
                    'jurisdiction': 'CA',
                    'province': 'ON',
                    'employment_income': 80000,
                    'rrsp_contribution': 10000,
                    'investment_income': 2000
                },
                'expected': {
                    'federal_tax': 11421,  # Based on 2025 rates
                    'tolerance': 0.01
                }
            }
        ]
        
        for case in test_cases:
            result = personal_engine.calculate_personal_tax(case['input'])
            
            expected = case['expected']['federal_tax']
            actual = result['federal_tax']
            error = abs(expected - actual) / expected if expected != 0 else 0
            
            assert error <= case['expected']['tolerance'], \
                f"{case['description']}: Expected {expected}, got {actual} (error: {error*100:.2f}%)"
    
    def test_response_validation(self, validator):
        """
        Tests response validation accuracy
        """
        test_response = {
            'answer': 'The small business deduction rate is 19%',
            'citations': ['ITA s.125(1)', 'CRA Folio S4-F15-C1'],
            'calculations': {
                'federal_tax': {
                    'inputs': {'income': 150000, 'rate': 0.09},
                    'result': 13500
                }
            },
            'confidence': 0.95
        }
        
        validation_result = validator.validate_response(
            query='What is the small business deduction rate?',
            response=test_response,
            context={'jurisdiction': 'CA'}
        )
        
        assert validation_result['is_valid'] == True
        assert validation_result['confidence_score'] >= 0.95
        assert len(validation_result['corrections_needed']) == 0
    
    def test_fraud_detection_accuracy(self, tax_engine):
        """
        Tests fraud detection accuracy
        """
        # Mock fraud detection system
        class MockFraudDetector:
            def analyze_filing(self, data):
                # If expenses are close to revenue, flag as suspicious
                if data['expenses'] / data['revenue'] > 0.95:
                    return {
                        'risk_score': 85,
                        'risk_level': 'HIGH',
                        'flags': ['High expense ratio']
                    }
                return {
                    'risk_score': 20,
                    'risk_level': 'LOW',
                    'flags': []
                }
        
        detector = MockFraudDetector()
        
        # Test with suspicious data
        suspicious_data = {
            'revenue': 1000000,
            'expenses': 999000,  # 99.9% expense ratio
        }
        
        result = detector.analyze_filing(suspicious_data)
        
        assert result['risk_score'] > 70
        assert result['risk_level'] in ['HIGH', 'CRITICAL']
        assert len(result['flags']) > 0
    
    def test_edge_cases(self, tax_engine, personal_engine):
        """
        Tests edge cases for accuracy
        """
        # Mock engines for edge cases
        class MockTaxEngine:
            def calculate_tax(self, input_data):
                if 'revenue' in input_data and 'expenses' in input_data:
                    if input_data['revenue'] == 0:
                        return {'tax': 0}
                    elif input_data['expenses'] > input_data['revenue']:
                        return {'tax': 0, 'loss_carryforward': input_data['expenses'] - input_data['revenue']}
                return {'tax': 0}
        
        class MockPersonalEngine:
            def calculate_tax(self, input_data):
                # For high income, return highest marginal rate
                if input_data.get('wages', 0) > 1000000:
                    return {'marginal_rate': 0.37}
                return {'marginal_rate': 0.22}
        
        edge_cases = [
            # Zero income
            {
                'engine': MockTaxEngine(),
                'input': {'revenue': 0, 'expenses': 50000},
                'expected': {'tax': 0}
            },
            # Negative income
            {
                'engine': MockTaxEngine(),
                'input': {'revenue': 100000, 'expenses': 150000},
                'expected': {'tax': 0, 'loss_carryforward': 50000}
            },
            # Maximum values
            {
                'engine': MockPersonalEngine(),
                'input': {
                    'wages': 10000000,
                    'capital_gains': 5000000,
                    'jurisdiction': 'US',
                    'filing_status': 'single'
                },
                'expected': {'marginal_rate': 0.37}
            }
        ]
        
        for case in edge_cases:
            result = case['engine'].calculate_tax(case['input'])
            
            for key, expected_value in case['expected'].items():
                assert key in result, f"Missing expected key: {key}"
                if isinstance(expected_value, (int, float)):
                    assert abs(result[key] - expected_value) < 0.01