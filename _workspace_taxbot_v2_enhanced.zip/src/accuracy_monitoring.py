import asyncio
from datetime import datetime, timedelta
import pandas as pd
from typing import Dict, List
import logging

class AccuracyMonitor:
    """
    Real-time monitoring system for chatbot accuracy
    """
    
    def __init__(self):
        self.metrics = {
            'response_accuracy': [],
            'calculation_accuracy': [],
            'citation_accuracy': [],
            'user_satisfaction': []
        }
        self.alert_thresholds = {
            'accuracy': 0.95,
            'response_time': 3.0,  # seconds
            'error_rate': 0.05
        }
        self.logger = self.setup_logging()
    
    async def monitor_response(self, request: dict, response: dict, actual_result: dict = None):
        """
        Monitors individual response for accuracy
        """
        monitoring_data = {
            'timestamp': datetime.utcnow(),
            'request_id': request.get('id'),
            'response_time': response.get('processing_time'),
            'confidence_score': response.get('confidence', 0)
        }
        
        # Accuracy checks
        if actual_result:
            accuracy_score = self.calculate_accuracy_score(response, actual_result)
            monitoring_data['accuracy_score'] = accuracy_score
            
            if accuracy_score < self.alert_thresholds['accuracy']:
                await self.trigger_accuracy_alert(request, response, accuracy_score)
        
        # Response time check
        if monitoring_data['response_time'] > self.alert_thresholds['response_time']:
            await self.trigger_performance_alert(monitoring_data)
        
        # Store metrics
        self.metrics['response_accuracy'].append(monitoring_data)
        
        # Rolling accuracy calculation
        await self.calculate_rolling_accuracy()
    
    def calculate_accuracy_score(self, response: dict, actual: dict) -> float:
        """
        Calculates accuracy score by comparing response to actual result
        """
        score = 1.0
        
        # Check calculations
        if 'calculations' in response and 'calculations' in actual:
            for key in response['calculations']:
                if key in actual['calculations']:
                    expected = actual['calculations'][key]
                    provided = response['calculations'][key]
                    
                    if isinstance(expected, (int, float)) and isinstance(provided, (int, float)):
                        error = abs(expected - provided) / abs(expected) if expected != 0 else 0
                        score -= error * 0.5  # Weight calculation errors heavily
        
        # Check citations
        if 'citations' in response and 'citations' in actual:
            correct_citations = set(response['citations']) & set(actual['citations'])
            total_citations = len(set(response['citations']) | set(actual['citations']))
            citation_accuracy = len(correct_citations) / total_citations if total_citations > 0 else 1
            score *= citation_accuracy
        
        return max(0, min(1, score))
    
    async def calculate_rolling_accuracy(self):
        """
        Calculates rolling accuracy metrics
        """
        if len(self.metrics['response_accuracy']) >= 100:
            recent_responses = self.metrics['response_accuracy'][-100:]
            accuracy_scores = [r.get('accuracy_score', 1.0) for r in recent_responses]
            
            rolling_accuracy = sum(accuracy_scores) / len(accuracy_scores)
            
            if rolling_accuracy < self.alert_thresholds['accuracy']:
                await self.trigger_system_alert('Rolling accuracy below threshold', {
                    'current_accuracy': rolling_accuracy,
                    'threshold': self.alert_thresholds['accuracy'],
                    'sample_size': len(accuracy_scores)
                })
    
    async def trigger_accuracy_alert(self, request: dict, response: dict, accuracy_score: float):
        """
        Triggers alert for accuracy issues
        """
        alert = {
            'type': 'ACCURACY_ALERT',
            'severity': 'HIGH' if accuracy_score < 0.85 else 'MEDIUM',
            'timestamp': datetime.utcnow().isoformat(),
            'details': {
                'request': request,
                'response': response,
                'accuracy_score': accuracy_score
            }
        }
        
        # Log alert
        self.logger.error(f"Accuracy Alert: {json.dumps(alert)}")
        
        # Send to monitoring system
        await self.send_to_monitoring_system(alert)
        
        # Trigger retraining if needed
        if accuracy_score < 0.80:
            await self.trigger_model_retraining(request['query_type'])
    
    def generate_accuracy_report(self) -> dict:
        """
        Generates comprehensive accuracy report
        """
        df = pd.DataFrame(self.metrics['response_accuracy'])
        
        if len(df) == 0:
            return {'status': 'No data available'}
        
        report = {
            'period': {
                'start': df['timestamp'].min().isoformat(),
                'end': df['timestamp'].max().isoformat()
            },
            'total_responses': len(df),
            'accuracy_metrics': {
                'mean_accuracy': df['accuracy_score'].mean() if 'accuracy_score' in df else None,
                'median_accuracy': df['accuracy_score'].median() if 'accuracy_score' in df else None,
                'min_accuracy': df['accuracy_score'].min() if 'accuracy_score' in df else None,
                'accuracy_std': df['accuracy_score'].std() if 'accuracy_score' in df else None
            },
            'performance_metrics': {
                'mean_response_time': df['response_time'].mean(),
                'p95_response_time': df['response_time'].quantile(0.95),
                'p99_response_time': df['response_time'].quantile(0.99)
            },
            'alerts_triggered': self.count_alerts(),
            'recommendations': self.generate_recommendations(df)
        }
        
        return report