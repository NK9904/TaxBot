import asyncio
import aiohttp
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import hashlib
import json
import logging
from datetime import datetime
from typing import Dict, List, Optional
import os

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TaxCodeScraper:
    """
    Scrapes and structures US IRS and Canadian CRA tax codes.
    This class handles scraping from multiple jurisdictions and sources,
    with proper error handling and data validation.
    """
    
    def __init__(self):
        self.sources = {
            'us_federal': {
                'irs_code': 'https://www.law.cornell.edu/uscode/text/26',
                'irs_pubs': 'https://www.irs.gov/publications',
                'treasury_regs': 'https://www.ecfr.gov/current/title-26',
                'tax_court': 'https://www.ustaxcourt.gov/opinions.html'
            },
            'canadian_federal': {
                'income_tax_act': 'https://laws-lois.justice.gc.ca/eng/acts/I-3.3/',
                'cra_folios': 'https://www.canada.ca/en/revenue-agency/services/tax/technical-information/income-tax/income-tax-folios.html',
                'tax_court': 'https://www.tcc-cci.gc.ca/',
                'interpretations': 'https://www.canada.ca/en/revenue-agency/services/tax/technical-information/income-tax/technical-interpretations.html'
            }
        }
        
        self.scraped_data = []
        self.validation_checksums = {}
        self.data_dir = "data"
        
        # Create data directory if it doesn't exist
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)
    
    async def scrape_all_sources(self) -> Dict:
        """
        Orchestrates scraping from all tax code sources.
        
        Returns:
            Dict: Contains structured data, validation report, and timestamp.
        """
        logger.info("Starting scraping from all sources...")
        tasks = []
        
        # Federal sources
        for jurisdiction, sources in self.sources.items():
            for source_name, url in sources.items():
                if isinstance(url, str):
                    tasks.append(self.scrape_source(url, jurisdiction, source_name))
                elif isinstance(url, dict):
                    for sub_name, sub_url in url.items():
                        tasks.append(self.scrape_source(sub_url, jurisdiction, f"{source_name}_{sub_name}"))
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Process and structure results
        structured_data = self.structure_tax_data(results)
        
        # Validate completeness
        validation_report = self.validate_scraped_data(structured_data)
        
        # Save data to file
        self.save_scraped_data(structured_data)
        
        logger.info("Completed scraping from all sources.")
        return {
            'data': structured_data,
            'validation': validation_report,
            'timestamp': datetime.utcnow().isoformat()
        }
    
    async def scrape_source(self, url: str, jurisdiction: str, source_name: str) -> Optional[Dict]:
        """
        Scrapes individual tax code source.
        
        Args:
            url (str): URL to scrape
            jurisdiction (str): Jurisdiction (us_federal, canadian_federal)
            source_name (str): Name of the source
            
        Returns:
            Optional[Dict]: Scraped data or None if error occurred
        """
        logger.info(f"Scraping {source_name} from {jurisdiction}...")
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status != 200:
                        logger.error(f"Failed to fetch {url}: HTTP {response.status}")
                        return None
                    
                    html = await response.text()
                    soup = BeautifulSoup(html, 'html.parser')
                    
                    # Extract structured data based on source type
                    if 'irs.gov' in url:
                        data = self.parse_irs_content(soup)
                    elif 'canada.ca' in url:
                        data = self.parse_cra_content(soup)
                    elif 'law.cornell.edu' in url:
                        data = self.parse_uscode_content(soup)
                    else:
                        data = self.parse_generic_legal_content(soup)
                    
                    result = {
                        'jurisdiction': jurisdiction,
                        'source': source_name,
                        'url': url,
                        'content': data,
                        'checksum': hashlib.sha256(str(data).encode()).hexdigest(),
                        'scraped_at': datetime.utcnow().isoformat()
                    }
                    
                    logger.info(f"Successfully scraped {source_name} from {jurisdiction}")
                    return result
        except aiohttp.ClientError as e:
            logger.error(f"Client error scraping {url}: {str(e)}")
            return None
        except Exception as e:
            logger.error(f"Error scraping {url}: {str(e)}")
            return None
    
    def parse_irs_content(self, soup: BeautifulSoup) -> List[Dict]:
        """
        Specialized parser for IRS content.
        
        Args:
            soup (BeautifulSoup): BeautifulSoup object containing parsed HTML
            
        Returns:
            List[Dict]: Parsed content sections
        """
        sections = []
        
        # Extract sections, subsections, and provisions
        for section in soup.find_all(['h1', 'h2', 'h3', 'h4']):
            section_data = {
                'title': section.get_text().strip(),
                'level': section.name,
                'content': [],
                'provisions': []
            }
            
            # Get content until next heading
            current = section.next_sibling
            while current and current.name not in ['h1', 'h2', 'h3', 'h4']:
                if current.name == 'p':
                    section_data['content'].append(current.get_text().strip())
                elif current.name in ['ol', 'ul']:
                    provisions = [li.get_text().strip() for li in current.find_all('li')]
                    section_data['provisions'].extend(provisions)
                current = current.next_sibling
            
            sections.append(section_data)
        
        return sections
    
    def parse_cra_content(self, soup: BeautifulSoup) -> List[Dict]:
        """
        Specialized parser for CRA content.
        
        Args:
            soup (BeautifulSoup): BeautifulSoup object containing parsed HTML
            
        Returns:
            List[Dict]: Parsed content sections
        """
        sections = []
        
        # Extract sections from CRA content
        for section in soup.find_all(['h2', 'h3', 'h4']):
            section_data = {
                'title': section.get_text().strip(),
                'level': section.name,
                'content': [],
                'provisions': []
            }
            
            # Get content until next heading
            current = section.next_sibling
            while current and current.name not in ['h2', 'h3', 'h4']:
                if current.name == 'p':
                    section_data['content'].append(current.get_text().strip())
                elif current.name in ['ol', 'ul']:
                    provisions = [li.get_text().strip() for li in current.find_all('li')]
                    section_data['provisions'].extend(provisions)
                current = current.next_sibling
            
            sections.append(section_data)
        
        return sections
    
    def parse_uscode_content(self, soup: BeautifulSoup) -> List[Dict]:
        """
        Specialized parser for US Code content.
        
        Args:
            soup (BeautifulSoup): BeautifulSoup object containing parsed HTML
            
        Returns:
            List[Dict]: Parsed content sections
        """
        sections = []
        
        # Extract sections from US Code content
        for section in soup.find_all(['h3', 'h4', 'h5']):
            section_data = {
                'title': section.get_text().strip(),
                'level': section.name,
                'content': [],
                'provisions': []
            }
            
            # Get content until next heading
            current = section.next_sibling
            while current and current.name not in ['h3', 'h4', 'h5']:
                if current.name == 'p':
                    section_data['content'].append(current.get_text().strip())
                elif current.name in ['ol', 'ul']:
                    provisions = [li.get_text().strip() for li in current.find_all('li')]
                    section_data['provisions'].extend(provisions)
                current = current.next_sibling
            
            sections.append(section_data)
        
        return sections
    
    def parse_generic_legal_content(self, soup: BeautifulSoup) -> List[Dict]:
        """
        Generic parser for legal content.
        
        Args:
            soup (BeautifulSoup): BeautifulSoup object containing parsed HTML
            
        Returns:
            List[Dict]: Parsed content sections
        """
        sections = []
        
        # Extract all headings as sections
        for section in soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6']):
            section_data = {
                'title': section.get_text().strip(),
                'level': section.name,
                'content': [],
                'provisions': []
            }
            
            # Get content until next heading
            current = section.next_sibling
            while current and current.name not in ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
                if current.name == 'p':
                    section_data['content'].append(current.get_text().strip())
                elif current.name in ['ol', 'ul']:
                    provisions = [li.get_text().strip() for li in current.find_all('li')]
                    section_data['provisions'].extend(provisions)
                current = current.next_sibling
            
            sections.append(section_data)
        
        return sections
    
    def structure_tax_data(self, raw_data: List[Dict]) -> Dict:
        """
        Structures scraped data into hierarchical format.
        
        Args:
            raw_data (List[Dict]): Raw scraped data
            
        Returns:
            Dict: Structured tax data
        """
        structured = {
            'corporate_tax': {
                'us': {
                    'federal': {},
                    'state': {}
                },
                'canada': {
                    'federal': {},
                    'provincial': {}
                }
            },
            'personal_tax': {
                'us': {
                    'federal': {},
                    'state': {}
                },
                'canada': {
                    'federal': {},
                    'provincial': {}
                }
            },
            'cross_border': {},
            'tax_treaties': {},
            'case_law': {}
        }
        
        for item in raw_data:
            if item and not isinstance(item, Exception) and item.get('content'):
                self.categorize_content(item, structured)
        
        return structured
    
    def categorize_content(self, item: Dict, structured: Dict):
        """
        Categorizes scraped content into appropriate sections.
        
        Args:
            item (Dict): Individual scraped item
            structured (Dict): Structured data dictionary to populate
        """
        jurisdiction = item.get('jurisdiction', '')
        source = item.get('source', '')
        content = item.get('content', [])
        
        # Categorize based on jurisdiction and source
        if 'us' in jurisdiction:
            if 'irs_code' in source or 'uscode' in source:
                structured['corporate_tax']['us']['federal'][source] = content
                structured['personal_tax']['us']['federal'][source] = content
            elif 'irs_pubs' in source:
                structured['personal_tax']['us']['federal'][source] = content
            elif 'treasury_regs' in source:
                structured['corporate_tax']['us']['federal'][source] = content
            elif 'tax_court' in source:
                structured['case_law']['us'] = content
        elif 'canadian' in jurisdiction:
            if 'income_tax_act' in source:
                structured['corporate_tax']['canada']['federal'][source] = content
                structured['personal_tax']['canada']['federal'][source] = content
            elif 'cra_folios' in source:
                structured['personal_tax']['canada']['federal'][source] = content
            elif 'interpretations' in source:
                structured['corporate_tax']['canada']['federal'][source] = content
            elif 'tax_court' in source:
                structured['case_law']['canada'] = content
    
    def validate_scraped_data(self, structured_data: Dict) -> Dict:
        """
        Validates completeness of scraped data.
        
        Args:
            structured_data (Dict): Structured tax data
            
        Returns:
            Dict: Validation report
        """
        validation_report = {
            'total_sources': 0,
            'successful_sources': 0,
            'failed_sources': [],
            'data_completeness': 0.0
        }
        
        # Count total expected sources
        total_sources = 0
        successful_sources = 0
        
        for jurisdiction, sources in self.sources.items():
            for source_name, url in sources.items():
                total_sources += 1
                if isinstance(url, str):
                    # Check if we have content for this source
                    if self._check_source_content(jurisdiction, source_name, structured_data):
                        successful_sources += 1
                    else:
                        validation_report['failed_sources'].append(f"{jurisdiction}/{source_name}")
                elif isinstance(url, dict):
                    for sub_name, sub_url in url.items():
                        total_sources += 1
                        if self._check_source_content(jurisdiction, f"{source_name}_{sub_name}", structured_data):
                            successful_sources += 1
                        else:
                            validation_report['failed_sources'].append(f"{jurisdiction}/{source_name}_{sub_name}")
        
        validation_report['total_sources'] = total_sources
        validation_report['successful_sources'] = successful_sources
        validation_report['data_completeness'] = successful_sources / total_sources if total_sources > 0 else 0.0
        
        return validation_report
    
    def _check_source_content(self, jurisdiction: str, source_name: str, structured_data: Dict) -> bool:
        """
        Checks if content exists for a specific source.
        
        Args:
            jurisdiction (str): Jurisdiction name
            source_name (str): Source name
            structured_data (Dict): Structured data to check
            
        Returns:
            bool: True if content exists, False otherwise
        """
        # Simplified check - in a real implementation, this would be more detailed
        if 'us' in jurisdiction:
            return len(structured_data['corporate_tax']['us']['federal']) > 0 or \
                   len(structured_data['personal_tax']['us']['federal']) > 0
        elif 'canadian' in jurisdiction:
            return len(structured_data['corporate_tax']['canada']['federal']) > 0 or \
                   len(structured_data['personal_tax']['canada']['federal']) > 0
        return False
    
    def save_scraped_data(self, structured_data: Dict):
        """
        Saves scraped data to file for persistence.
        
        Args:
            structured_data (Dict): Structured data to save
        """
        try:
            filename = f"{self.data_dir}/tax_data_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
            with open(filename, 'w') as f:
                json.dump(structured_data, f, indent=2)
            logger.info(f"Saved scraped data to {filename}")
        except Exception as e:
            logger.error(f"Failed to save scraped data: {str(e)}")