import logging
import hashlib
import secrets
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import json
import re

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SecurityManager:
    """
    Security manager for TaxBot system.
    Handles authentication, authorization, input validation, and encryption.
    """
    
    def __init__(self):
        self.sessions = {}
        self.rate_limits = {}
        self.sensitive_patterns = [
            r'\b\d{3}-\d{2}-\d{4}\b',  # SSN pattern
            r'\b\d{9}\b',              # 9-digit numbers (potential SSN)
            r'\b[A-Z]{2}\d{6}\b',      # Canadian SIN pattern
            r'\b\d{4}\s?\d{4}\s?\d{4}\s?\d{4}\b',  # Credit card pattern
            r'\b\d{16}\b'             # 16-digit numbers (potential CC)
        ]
        logger.info("Security Manager initialized")
    
    def hash_password(self, password: str) -> str:
        """
        Hash a password using SHA-256.
        
        Args:
            password (str): Plain text password
            
        Returns:
            str: Hashed password
        """
        return hashlib.sha256(password.encode()).hexdigest()
    
    def generate_session_token(self) -> str:
        """
        Generate a secure session token.
        
        Returns:
            str: Session token
        """
        return secrets.token_urlsafe(32)
    
    def create_session(self, user_id: str) -> str:
        """
        Create a new session for a user.
        
        Args:
            user_id (str): User identifier
            
        Returns:
            str: Session token
        """
        token = self.generate_session_token()
        self.sessions[token] = {
            'user_id': user_id,
            'created_at': datetime.utcnow(),
            'expires_at': datetime.utcnow() + timedelta(hours=24)
        }
        logger.info(f"Created session for user {user_id}")
        return token
    
    def validate_session(self, token: str) -> Optional[str]:
        """
        Validate a session token.
        
        Args:
            token (str): Session token
            
        Returns:
            Optional[str]: User ID if valid, None if invalid
        """
        session = self.sessions.get(token)
        if not session:
            logger.warning("Session validation failed: token not found")
            return None
        
        if datetime.utcnow() > session['expires_at']:
            logger.warning(f"Session validation failed: token expired for user {session['user_id']}")
            del self.sessions[token]
            return None
        
        return session['user_id']
    
    def validate_input(self, input_text: str) -> Dict:
        """
        Validate and sanitize user input.
        
        Args:
            input_text (str): User input to validate
            
        Returns:
            Dict: Validation results
        """
        logger.info("Validating user input...")
        
        validation_result = {
            'is_valid': True,
            'sanitized_text': input_text,
            'detected_sensitive_data': [],
            'validation_warnings': []
        }
        
        # Check for sensitive data patterns
        for pattern in self.sensitive_patterns:
            matches = re.findall(pattern, input_text)
            if matches:
                validation_result['detected_sensitive_data'].extend(matches)
                validation_result['is_valid'] = False
                logger.warning(f"Sensitive data detected in input: {matches}")
        
        # Check for SQL injection patterns
        sql_injection_patterns = [
            r"(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION)\b)",
            r"(';|&quot;;|--|\/\*|\*\/)",
            r"(OR\s+\d+\s*=\s*\d+)"
        ]
        
        for pattern in sql_injection_patterns:
            if re.search(pattern, input_text, re.IGNORECASE):
                validation_result['is_valid'] = False
                validation_result['validation_warnings'].append("Potential SQL injection detected")
                logger.warning("Potential SQL injection detected in input")
        
        # Sanitize input by removing or replacing sensitive content
        if not validation_result['is_valid']:
            sanitized_text = input_text
            for match in validation_result['detected_sensitive_data']:
                sanitized_text = sanitized_text.replace(match, "[REDACTED]")
            validation_result['sanitized_text'] = sanitized_text
        
        return validation_result
    
    def check_rate_limit(self, user_id: str, limit: int = 100, window_minutes: int = 60) -> bool:
        """
        Check if user has exceeded rate limit.
        
        Args:
            user_id (str): User identifier
            limit (int): Maximum requests per window
            window_minutes (int): Time window in minutes
            
        Returns:
            bool: True if within limit, False if exceeded
        """
        now = datetime.utcnow()
        window_start = now - timedelta(minutes=window_minutes)
        
        if user_id not in self.rate_limits:
            self.rate_limits[user_id] = []
        
        # Remove old requests outside the window
        self.rate_limits[user_id] = [
            timestamp for timestamp in self.rate_limits[user_id] 
            if timestamp > window_start
        ]
        
        # Check if limit is exceeded
        current_requests = len(self.rate_limits[user_id])
        within_limit = current_requests < limit
        
        if within_limit:
            self.rate_limits[user_id].append(now)
            logger.debug(f"User {user_id} made request {current_requests + 1}/{limit}")
        else:
            logger.warning(f"User {user_id} exceeded rate limit: {current_requests}/{limit}")
        
        return within_limit
    
    def encrypt_data(self, data: str, key: str) -> str:
        """
        Encrypt sensitive data.
        Note: This is a simplified implementation. In production, use proper encryption libraries.
        
        Args:
            data (str): Data to encrypt
            key (str): Encryption key
            
        Returns:
            str: Encrypted data
        """
        # In a real implementation, this would use proper encryption
        # For this example, we'll use a simple XOR cipher for demonstration
        encrypted = ''.join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(data))
        return encrypted.encode('utf-8').hex()
    
    def decrypt_data(self, encrypted_data: str, key: str) -> str:
        """
        Decrypt sensitive data.
        Note: This is a simplified implementation. In production, use proper encryption libraries.
        
        Args:
            encrypted_data (str): Data to decrypt
            key (str): Encryption key
            
        Returns:
            str: Decrypted data
        """
        # In a real implementation, this would use proper decryption
        # For this example, we'll use a simple XOR cipher for demonstration
        try:
            data_bytes = bytes.fromhex(encrypted_data)
            data = data_bytes.decode('utf-8')
            decrypted = ''.join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(data))
            return decrypted
        except Exception as e:
            logger.error(f"Decryption failed: {str(e)}")
            return ""

class AuditLogger:
    """
    Audit logger for compliance tracking.
    """
    
    def __init__(self):
        self.audit_log = []
        logger.info("Audit Logger initialized")
    
    def log_user_action(self, user_id: str, action: str, details: Dict):
        """
        Log user action for audit purposes.
        
        Args:
            user_id (str): User identifier
            action (str): Action performed
            details (Dict): Action details
        """
        audit_entry = {
            'timestamp': datetime.utcnow().isoformat(),
            'user_id': user_id,
            'action': action,
            'details': details
        }
        
        self.audit_log.append(audit_entry)
        logger.info(f"Audit log entry: User {user_id} performed {action}")
    
    def log_system_event(self, event_type: str, details: Dict):
        """
        Log system event for audit purposes.
        
        Args:
            event_type (str): Type of system event
            details (Dict): Event details
        """
        audit_entry = {
            'timestamp': datetime.utcnow().isoformat(),
            'event_type': event_type,
            'details': details
        }
        
        self.audit_log.append(audit_entry)
        logger.info(f"Audit log entry: System event {event_type}")
    
    def get_audit_log(self) -> List[Dict]:
        """
        Get the audit log.
        
        Returns:
            List[Dict]: Audit log entries
        """
        return self.audit_log
    
    def export_audit_log(self, filename: str):
        """
        Export audit log to a file.
        
        Args:
            filename (str): Filename to export to
        """
        try:
            with open(filename, 'w') as f:
                json.dump(self.audit_log, f, indent=2)
            logger.info(f"Audit log exported to {filename}")
        except Exception as e:
            logger.error(f"Failed to export audit log: {str(e)}")

# Example usage
if __name__ == "__main__":
    security = SecurityManager()
    audit = AuditLogger()
    
    # Create a session
    token = security.create_session("user123")
    print(f"Session token: {token}")
    
    # Validate session
    user_id = security.validate_session(token)
    print(f"Validated user ID: {user_id}")
    
    # Validate input
    test_input = "Calculate tax for income 100000 with SSN 123-45-6789"
    validation = security.validate_input(test_input)
    print(json.dumps(validation, indent=2))
    
    # Log audit events
    audit.log_user_action("user123", "tax_query", {"query": "What is corporate tax rate?"})
    audit.log_system_event("model_retraining", {"models": ["qa_model"], "status": "completed"})
    
    # Export audit log
    audit.export_audit_log("audit_log.json")