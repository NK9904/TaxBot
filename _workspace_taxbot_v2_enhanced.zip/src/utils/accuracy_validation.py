import numpy as np
from typing import Dict, List, Tuple
import json
import logging
from datetime import datetime
from decimal import Decimal

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AccuracyValidator:
    """
    Multi-layer validation system for ensuring accuracy of tax responses.
    This class implements five layers of validation to ensure high accuracy.
    """
    
    def __init__(self):
        self.validation_layers = [
            'syntax_validation',
            'semantic_validation',
            'calculation_verification',
            'cross_reference_check',
            'expert_review_flag'
        ]
        self.accuracy_logs = []
        self.error_threshold = 0.05  # 5% error tolerance
    
    def validate_response(self, query: str, response: Dict, context: Dict) -> Dict:
        """
        Validates chatbot response through multiple layers.
        
        Args:
            query (str): User query
            response (Dict): Response from the system
            context (Dict): Context information for validation
            
        Returns:
            Dict: Validation results including validity status and confidence score
        """
        logger.info(f"Validating response for query: {query[:50]}...")
        
        validation_results = {
            'is_valid': True,
            'confidence_score': 1.0,
            'validation_details': {},
            'corrections_needed': []
        }
        
        # Apply each validation layer
        for layer in self.validation_layers:
            layer_result = getattr(self, layer)(query, response, context)
            validation_results['validation_details'][layer] = layer_result
            
            # If any layer fails, mark response as invalid
            if not layer_result.get('valid', True):
                validation_results['is_valid'] = False
                validation_results['corrections_needed'].append(layer_result.get('correction', ''))
                # Reduce confidence score for each failed layer
                validation_results['confidence_score'] -= 0.2
        
        # Log validation results
        self.accuracy_logs.append({
            'query': query,
            'timestamp': datetime.utcnow().isoformat(),
            'validation_results': validation_results
        })
        
        logger.info(f"Validation completed. Valid: {validation_results['is_valid']}, Confidence: {validation_results['confidence_score']:.2f}")
        return validation_results
    
    def syntax_validation(self, query: str, response: Dict, context: Dict) -> Dict:
        """
        Validates syntax of the response.
        
        Args:
            query (str): User query
            response (Dict): Response from the system
            context (Dict): Context information for validation
            
        Returns:
            Dict: Syntax validation results
        """
        try:
            # Check if response is a valid dictionary
            if not isinstance(response, dict):
                return {
                    'valid': False,
                    'correction': 'Response must be a dictionary',
                    'details': f'Response type: {type(response)}'
                }
            
            # Check required fields
            required_fields = ['answer', 'confidence_score', 'jurisdiction', 'category']
            missing_fields = [field for field in required_fields if field not in response]
            
            if missing_fields:
                return {
                    'valid': False,
                    'correction': f'Missing required fields: {missing_fields}',
                    'details': list(response.keys())
                }
            
            # Validate data types
            if not isinstance(response.get('confidence_score', 0), (int, float)):
                return {
                    'valid': False,
                    'correction': 'Confidence score must be a number',
                    'details': f'Confidence score type: {type(response.get("confidence_score"))}'
                }
            
            return {
                'valid': True,
                'correction': None,
                'details': 'Syntax validation passed'
            }
        except Exception as e:
            logger.error(f"Syntax validation error: {str(e)}")
            return {
                'valid': False,
                'correction': f'Syntax validation failed: {str(e)}',
                'details': str(e)
            }
    
    def semantic_validation(self, query: str, response: Dict, context: Dict) -> Dict:
        """
        Validates semantic meaning of the response.
        
        Args:
            query (str): User query
            response (Dict): Response from the system
            context (Dict): Context information for validation
            
        Returns:
            Dict: Semantic validation results
        """
        try:
            answer = response.get('answer', '')
            
            # Check if answer is meaningful (not empty or too short)
            if len(answer.strip()) < 10:
                return {
                    'valid': False,
                    'correction': 'Response answer is too short to be meaningful',
                    'details': f'Answer length: {len(answer.strip())}'
                }
            
            # Check for placeholder responses
            placeholder_indicators = ['placeholder', 'dummy', 'example', 'sample']
            if any(indicator in answer.lower() for indicator in placeholder_indicators):
                return {
                    'valid': False,
                    'correction': 'Response contains placeholder content',
                    'details': 'Placeholder detected in answer'
                }
            
            # Check for appropriate tax terminology
            tax_terms = ['tax', 'income', 'deduction', 'credit', 'liability', 'return']
            if not any(term in answer.lower() for term in tax_terms):
                logger.warning("Response may lack tax-specific terminology")
            
            return {
                'valid': True,
                'correction': None,
                'details': 'Semantic validation passed'
            }
        except Exception as e:
            logger.error(f"Semantic validation error: {str(e)}")
            return {
                'valid': False,
                'correction': f'Semantic validation failed: {str(e)}',
                'details': str(e)
            }
    
    def calculation_verification(self, query: str, response: Dict, context: Dict) -> Dict:
        """
        Verifies tax calculations in the response.
        
        Args:
            query (str): User query
            response (Dict): Response from the system
            context (Dict): Context information for validation
            
        Returns:
            Dict: Calculation verification results
        """
        try:
            # Extract calculation data from response
            calculation_data = response.get('calculation', {})
            if not calculation_data:
                # If no calculation data, this validation layer is not applicable
                return {
                    'valid': True,
                    'correction': None,
                    'details': 'No calculation data to verify'
                }
            
            # Verify calculation fields
            required_calc_fields = ['income', 'tax_rate', 'tax_amount']
            missing_fields = [field for field in required_calc_fields if field not in calculation_data]
            
            if missing_fields:
                return {
                    'valid': False,
                    'correction': f'Missing calculation fields: {missing_fields}',
                    'details': list(calculation_data.keys())
                }
            
            # Verify calculation logic
            income = Decimal(str(calculation_data.get('income', 0)))
            tax_rate = Decimal(str(calculation_data.get('tax_rate', 0)))
            tax_amount = Decimal(str(calculation_data.get('tax_amount', 0)))
            
            expected_tax = income * tax_rate
            if abs(tax_amount - expected_tax) > Decimal('0.01'):
                return {
                    'valid': False,
                    'correction': f'Calculation error: expected {expected_tax}, got {tax_amount}',
                    'details': f'Income: {income}, Rate: {tax_rate}, Amount: {tax_amount}'
                }
            
            return {
                'valid': True,
                'correction': None,
                'details': 'Calculation verification passed'
            }
        except Exception as e:
            logger.error(f"Calculation verification error: {str(e)}")
            return {
                'valid': False,
                'correction': f'Calculation verification failed: {str(e)}',
                'details': str(e)
            }
    
    def cross_reference_check(self, query: str, response: Dict, context: Dict) -> Dict:
        """
        Cross-references response with multiple sources.
        
        Args:
            query (str): User query
            response (Dict): Response from the system
            context (Dict): Context information for validation
            
        Returns:
            Dict: Cross-reference check results
        """
        try:
            jurisdiction = response.get('jurisdiction', '').upper()
            category = response.get('category', '')
            
            # Check if we have data for this jurisdiction and category
            if jurisdiction not in ['US', 'CA']:
                return {
                    'valid': False,
                    'correction': f'Unsupported jurisdiction: {jurisdiction}',
                    'details': 'Supported jurisdictions: US, CA'
                }
            
            # Verify that the response aligns with known tax rules for jurisdiction
            if jurisdiction == 'US' and 'corporate' in category:
                # Check for references to US corporate tax rules
                answer = response.get('answer', '').lower()
                if '21%' not in answer and 'corporate' not in answer:
                    logger.warning("US corporate tax response may not reference correct tax rates")
            
            elif jurisdiction == 'CA' and 'corporate' in category:
                # Check for references to Canadian corporate tax rules
                answer = response.get('answer', '').lower()
                if 'federal' not in answer and 'provincial' not in answer:
                    logger.warning("Canadian corporate tax response may not reference jurisdiction-specific rules")
            
            return {
                'valid': True,
                'correction': None,
                'details': 'Cross-reference check passed'
            }
        except Exception as e:
            logger.error(f"Cross-reference check error: {str(e)}")
            return {
                'valid': False,
                'correction': f'Cross-reference check failed: {str(e)}',
                'details': str(e)
            }
    
    def expert_review_flag(self, query: str, response: Dict, context: Dict) -> Dict:
        """
        Flags responses that require expert review.
        
        Args:
            query (str): User query
            response (Dict): Response from the system
            context (Dict): Context information for validation
            
        Returns:
            Dict: Expert review flag results
        """
        try:
            answer = response.get('answer', '')
            confidence_score = response.get('confidence_score', 1.0)
            
            # Flag responses with low confidence
            if confidence_score < 0.7:
                return {
                    'valid': True,  # Valid but needs expert review
                    'correction': 'Response flagged for expert review due to low confidence',
                    'details': f'Confidence score: {confidence_score}',
                    'requires_expert_review': True
                }
            
            # Flag responses containing certain keywords that indicate complexity
            complex_keywords = [
                'complex', 'exception', 'special case', 'consult professional', 
                'depends on', 'varies by', 'subject to'
            ]
            
            if any(keyword in answer.lower() for keyword in complex_keywords):
                return {
                    'valid': True,  # Valid but needs expert review
                    'correction': 'Response flagged for expert review due to complexity indicators',
                    'details': 'Complexity keywords detected',
                    'requires_expert_review': True
                }
            
            return {
                'valid': True,
                'correction': None,
                'details': 'No expert review required',
                'requires_expert_review': False
            }
        except Exception as e:
            logger.error(f"Expert review flag error: {str(e)}")
            return {
                'valid': False,
                'correction': f'Expert review flag failed: {str(e)}',
                'details': str(e)
            }
    
    def get_accuracy_report(self) -> Dict:
        """
        Generates an accuracy report based on validation logs.
        
        Returns:
            Dict: Accuracy report
        """
        if not self.accuracy_logs:
            return {
                'total_validations': 0,
                'accuracy_rate': 0.0,
                'details': 'No validation logs available'
            }
        
        total_validations = len(self.accuracy_logs)
        valid_responses = sum(1 for log in self.accuracy_logs if log['validation_results']['is_valid'])
        
        accuracy_rate = valid_responses / total_validations if total_validations > 0 else 0.0
        
        # Get validation layer statistics
        layer_stats = {}
        for layer in self.validation_layers:
            passed_count = sum(1 for log in self.accuracy_logs 
                              if log['validation_results']['validation_details'][layer].get('valid', False))
            layer_stats[layer] = {
                'passed': passed_count,
                'failed': total_validations - passed_count,
                'rate': passed_count / total_validations if total_validations > 0 else 0.0
            }
        
        return {
            'total_validations': total_validations,
            'valid_responses': valid_responses,
            'accuracy_rate': accuracy_rate,
            'layer_statistics': layer_stats,
            'details': f'Accuracy rate: {accuracy_rate:.2%}'
        }