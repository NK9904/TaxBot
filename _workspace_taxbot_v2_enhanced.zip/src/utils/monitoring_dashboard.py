import pandas as pd
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List
import matplotlib.pyplot as plt
import seaborn as sns
import io
import base64

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TaxBotDashboard:
    """
    Real-time monitoring dashboard for TaxBot operations.
    This class provides comprehensive monitoring capabilities with visualization.
    """
    
    def __init__(self):
        self.metrics_collector = MetricsCollector()
        self.alert_manager = AlertManager()
        logger.info("TaxBot Dashboard initialized")
    
    def get_dashboard_data(self) -> Dict:
        """
        Provides real-time dashboard data.
        
        Returns:
            Dict: Dashboard data including accuracy metrics, performance metrics, 
                  business metrics, and system health
        """
        logger.info("Generating dashboard data...")
        return {
            'accuracy_metrics': {
                'current_accuracy': self.get_current_accuracy(),
                'accuracy_trend': self.get_accuracy_trend(),
                'accuracy_by_category': self.get_category_accuracy(),
                'accuracy_chart': self.generate_accuracy_chart()
            },
            'performance_metrics': {
                'response_times': self.get_response_times(),
                'throughput': self.get_throughput(),
                'error_rates': self.get_error_rates(),
                'performance_chart': self.generate_performance_chart()
            },
            'business_metrics': {
                'user_satisfaction': self.get_satisfaction_scores(),
                'query_volume': self.get_query_volume(),
                'revenue_impact': self.calculate_revenue_impact(),
                'subscription_chart': self.generate_subscription_chart()
            },
            'system_health': {
                'model_status': self.check_model_health(),
                'infrastructure_status': self.check_infrastructure(),
                'data_freshness': self.check_data_freshness(),
                'health_chart': self.generate_health_chart()
            }
        }
    
    def get_current_accuracy(self) -> float:
        """
        Get current system accuracy.
        
        Returns:
            float: Current accuracy score
        """
        # In a real implementation, this would fetch from actual metrics
        return 0.96
    
    def get_accuracy_trend(self) -> List[float]:
        """
        Get accuracy trend over time.
        
        Returns:
            List[float]: Accuracy scores over time
        """
        # In a real implementation, this would fetch historical data
        return [0.95, 0.96, 0.97, 0.96, 0.95]
    
    def get_category_accuracy(self) -> Dict:
        """
        Get accuracy by tax category.
        
        Returns:
            Dict: Accuracy scores by category
        """
        return {
            'corporate_tax': 0.97,
            'personal_tax': 0.95,
            'cross_border': 0.92
        }
    
    def get_response_times(self) -> Dict:
        """
        Get response time metrics.
        
        Returns:
            Dict: Response time statistics
        """
        return {
            'average': 1.2,
            'p95': 2.1,
            'p99': 3.5
        }
    
    def get_throughput(self) -> int:
        """
        Get queries per second.
        
        Returns:
            int: Queries per second
        """
        return 10
    
    def get_error_rates(self) -> Dict:
        """
        Get system error rates.
        
        Returns:
            Dict: Error rates by type
        """
        return {
            'api_errors': 0.01,
            'model_errors': 0.02,
            'data_errors': 0.005
        }
    
    def get_satisfaction_scores(self) -> Dict:
        """
        Get user satisfaction metrics.
        
        Returns:
            Dict: Satisfaction scores
        """
        return {
            'average_rating': 4.5,
            'positive_feedback': 0.85,
            'negative_feedback': 0.15
        }
    
    def get_query_volume(self) -> Dict:
        """
        Get query volume statistics.
        
        Returns:
            Dict: Query volume data
        """
        return {
            'daily': 10000,
            'monthly': 300000,
            'by_jurisdiction': {
                'us': 60000,
                'ca': 40000
            }
        }
    
    def calculate_revenue_impact(self) -> float:
        """
        Calculate revenue impact of the system.
        
        Returns:
            float: Revenue impact in dollars
        """
        return 500000
    
    def check_model_health(self) -> str:
        """
        Check model health status.
        
        Returns:
            str: Model health status
        """
        return "healthy"
    
    def check_infrastructure(self) -> str:
        """
        Check infrastructure status.
        
        Returns:
            str: Infrastructure status
        """
        return "operational"
    
    def check_data_freshness(self) -> str:
        """
        Check how fresh the tax data is.
        
        Returns:
            str: Data freshness date
        """
        return "2025-10-01"
    
    def generate_accuracy_chart(self) -> str:
        """
        Generate accuracy trend chart as base64 encoded image.
        
        Returns:
            str: Base64 encoded chart image
        """
        try:
            # Sample data for chart
            dates = pd.date_range(datetime.now() - timedelta(days=30), periods=5, freq='7D')
            accuracy_scores = [0.92, 0.94, 0.95, 0.96, 0.97]
            
            # Create chart
            plt.figure(figsize=(10, 6))
            plt.plot(dates, accuracy_scores, marker='o', linewidth=2, markersize=8)
            plt.title('TaxBot Accuracy Trend')
            plt.xlabel('Date')
            plt.ylabel('Accuracy Score')
            plt.ylim(0.85, 1.0)
            plt.grid(True, alpha=0.3)
            
            # Save to base64 string
            buffer = io.BytesIO()
            plt.savefig(buffer, format='png')
            buffer.seek(0)
            chart_data = base64.b64encode(buffer.getvalue()).decode()
            plt.close()
            
            return chart_data
        except Exception as e:
            logger.error(f"Failed to generate accuracy chart: {str(e)}")
            return ""
    
    def generate_performance_chart(self) -> str:
        """
        Generate performance chart as base64 encoded image.
        
        Returns:
            str: Base64 encoded chart image
        """
        try:
            # Sample data for chart
            categories = ['API Response', 'Model Processing', 'Data Retrieval']
            times = [1.2, 0.8, 0.4]
            
            # Create chart
            plt.figure(figsize=(10, 6))
            bars = plt.bar(categories, times, color=['#4CAF50', '#2196F3', '#FF9800'])
            plt.title('TaxBot Performance Metrics')
            plt.xlabel('Operation Type')
            plt.ylabel('Average Time (seconds)')
            plt.grid(True, alpha=0.3)
            
            # Add value labels on bars
            for bar in bars:
                height = bar.get_height()
                plt.text(bar.get_x() + bar.get_width()/2., height,
                        f'{height:.1f}s',
                        ha='center', va='bottom')
            
            # Save to base64 string
            buffer = io.BytesIO()
            plt.savefig(buffer, format='png')
            buffer.seek(0)
            chart_data = base64.b64encode(buffer.getvalue()).decode()
            plt.close()
            
            return chart_data
        except Exception as e:
            logger.error(f"Failed to generate performance chart: {str(e)}")
            return ""
    
    def generate_subscription_chart(self) -> str:
        """
        Generate subscription usage chart as base64 encoded image.
        
        Returns:
            str: Base64 encoded chart image
        """
        try:
            # Sample data for chart
            subscription_types = ['Free', 'Basic', 'Premium', 'Enterprise']
            user_counts = [1500, 3200, 1800, 450]
            
            # Create chart
            plt.figure(figsize=(10, 6))
            bars = plt.bar(subscription_types, user_counts, 
                          color=['#9E9E9E', '#4CAF50', '#2196F3', '#9C27B0'])
            plt.title('TaxBot Subscription Distribution')
            plt.xlabel('Subscription Type')
            plt.ylabel('Number of Users')
            plt.grid(True, alpha=0.3)
            
            # Add value labels on bars
            for bar in bars:
                height = bar.get_height()
                plt.text(bar.get_x() + bar.get_width()/2., height,
                        f'{int(height)}',
                        ha='center', va='bottom')
            
            # Save to base64 string
            buffer = io.BytesIO()
            plt.savefig(buffer, format='png')
            buffer.seek(0)
            chart_data = base64.b64encode(buffer.getvalue()).decode()
            plt.close()
            
            return chart_data
        except Exception as e:
            logger.error(f"Failed to generate subscription chart: {str(e)}")
            return ""
    
    def generate_health_chart(self) -> str:
        """
        Generate system health chart as base64 encoded image.
        
        Returns:
            str: Base64 encoded chart image
        """
        try:
            # Sample data for chart
            components = ['Data Scraper', 'Models', 'API', 'Database', 'Cache']
            health_scores = [0.98, 0.95, 0.99, 0.97, 0.96]
            
            # Create chart
            plt.figure(figsize=(10, 6))
            bars = plt.bar(components, health_scores, color='#1ABC9C')
            plt.title('TaxBot System Health')
            plt.xlabel('Component')
            plt.ylabel('Health Score')
            plt.ylim(0.9, 1.0)
            plt.grid(True, alpha=0.3)
            
            # Add value labels on bars
            for bar in bars:
                height = bar.get_height()
                plt.text(bar.get_x() + bar.get_width()/2., height,
                        f'{height:.2f}',
                        ha='center', va='bottom')
            
            # Save to base64 string
            buffer = io.BytesIO()
            plt.savefig(buffer, format='png')
            buffer.seek(0)
            chart_data = base64.b64encode(buffer.getvalue()).decode()
            plt.close()
            
            return chart_data
        except Exception as e:
            logger.error(f"Failed to generate health chart: {str(e)}")
            return ""

class MetricsCollector:
    """
    Collects system metrics for monitoring and analysis.
    """
    
    def __init__(self):
        self.metrics = {}
        logger.info("Metrics Collector initialized")
    
    def collect_accuracy_metric(self, accuracy_score: float, category: str):
        """
        Collect accuracy metric for a specific category.
        
        Args:
            accuracy_score (float): Accuracy score
            category (str): Tax category
        """
        if 'accuracy' not in self.metrics:
            self.metrics['accuracy'] = {}
        
        self.metrics['accuracy'][category] = accuracy_score
        logger.debug(f"Collected accuracy metric for {category}: {accuracy_score}")
    
    def collect_response_time(self, response_time: float, endpoint: str):
        """
        Collect response time metric for an endpoint.
        
        Args:
            response_time (float): Response time in seconds
            endpoint (str): API endpoint
        """
        if 'response_times' not in self.metrics:
            self.metrics['response_times'] = {}
        
        self.metrics['response_times'][endpoint] = response_time
        logger.debug(f"Collected response time for {endpoint}: {response_time}s")
    
    def collect_error_rate(self, error_rate: float, error_type: str):
        """
        Collect error rate metric for a specific error type.
        
        Args:
            error_rate (float): Error rate
            error_type (str): Type of error
        """
        if 'error_rates' not in self.metrics:
            self.metrics['error_rates'] = {}
        
        self.metrics['error_rates'][error_type] = error_rate
        logger.debug(f"Collected error rate for {error_type}: {error_rate}")

class AlertManager:
    """
    Manages system alerts for monitoring.
    """
    
    def __init__(self):
        self.alerts = []
        logger.info("Alert Manager initialized")
    
    def check_accuracy_threshold(self, accuracy_score: float, threshold: float = 0.95):
        """
        Check if accuracy score is below threshold and create alert if needed.
        
        Args:
            accuracy_score (float): Current accuracy score
            threshold (float): Minimum acceptable threshold
        """
        if accuracy_score < threshold:
            alert = {
                'type': 'accuracy_warning',
                'message': f'Accuracy score {accuracy_score} is below threshold {threshold}',
                'timestamp': datetime.utcnow().isoformat(),
                'severity': 'warning'
            }
            self.alerts.append(alert)
            logger.warning(alert['message'])
    
    def check_response_time_threshold(self, response_time: float, threshold: float = 5.0):
        """
        Check if response time exceeds threshold and create alert if needed.
        
        Args:
            response_time (float): Current response time
            threshold (float): Maximum acceptable response time
        """
        if response_time > threshold:
            alert = {
                'type': 'performance_warning',
                'message': f'Response time {response_time}s exceeds threshold {threshold}s',
                'timestamp': datetime.utcnow().isoformat(),
                'severity': 'warning'
            }
            self.alerts.append(alert)
            logger.warning(alert['message'])
    
    def get_active_alerts(self) -> List[Dict]:
        """
        Get all active alerts.
        
        Returns:
            List[Dict]: List of active alerts
        """
        return self.alerts
    
    def clear_alerts(self):
        """
        Clear all alerts.
        """
        self.alerts.clear()
        logger.info("Alerts cleared")

# Example usage
if __name__ == "__main__":
    dashboard = TaxBotDashboard()
    data = dashboard.get_dashboard_data()
    print(json.dumps(data, indent=2))