import logging
import json
from datetime import datetime, timedelta
from typing import Dict, List
import pandas as pd
from utils.accuracy_validation import AccuracyValidator

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ContinuousImprovement:
    """
    Continuous improvement pipeline for TaxBot system.
    This class handles automated feedback processing and model retraining.
    """
    
    def __init__(self):
        self.validator = AccuracyValidator()
        self.improvement_log = []
        self.retraining_threshold = 0.90  # Retrain if accuracy drops below this
        self.feedback_window = 7  # Days to consider for feedback analysis
        logger.info("Continuous Improvement pipeline initialized")
    
    def analyze_feedback(self, feedback_data: List[Dict]) -> Dict:
        """
        Analyze user feedback to identify improvement opportunities.
        
        Args:
            feedback_data (List[Dict]): List of user feedback records
            
        Returns:
            Dict: Analysis results with improvement suggestions
        """
        logger.info("Analyzing user feedback...")
        
        # Convert to DataFrame for easier analysis
        df = pd.DataFrame(feedback_data)
        
        # Calculate feedback metrics
        total_feedback = len(df)
        positive_feedback = len(df[df['rating'] >= 4])
        negative_feedback = len(df[df['rating'] <= 2])
        
        # Calculate average rating
        avg_rating = df['rating'].mean() if total_feedback > 0 else 0
        
        # Identify common negative feedback themes
        negative_themes = self._identify_feedback_themes(df[df['rating'] <= 2])
        
        # Identify accuracy issues from feedback
        accuracy_issues = self._identify_accuracy_issues(feedback_data)
        
        analysis = {
            'feedback_metrics': {
                'total_feedback': total_feedback,
                'positive_feedback_ratio': positive_feedback / total_feedback if total_feedback > 0 else 0,
                'negative_feedback_ratio': negative_feedback / total_feedback if total_feedback > 0 else 0,
                'average_rating': avg_rating
            },
            'improvement_opportunities': {
                'negative_themes': negative_themes,
                'accuracy_issues': accuracy_issues,
                'suggested_actions': self._generate_improvement_actions(negative_themes, accuracy_issues)
            }
        }
        
        self.improvement_log.append({
            'timestamp': datetime.utcnow().isoformat(),
            'analysis': analysis
        })
        
        logger.info(f"Feedback analysis completed. Average rating: {avg_rating:.2f}")
        return analysis
    
    def _identify_feedback_themes(self, df: pd.DataFrame) -> List[Dict]:
        """
        Identify common themes in negative feedback.
        
        Args:
            df (pd.DataFrame): DataFrame with negative feedback
            
        Returns:
            List[Dict]: Common themes with frequency
        """
        themes = []
        
        # In a real implementation, this would use NLP to identify themes
        # For this example, we'll use simple keyword matching
        common_issues = {
            'calculation_errors': ['wrong', 'incorrect', 'calculate', 'math'],
            'incomplete_answers': ['incomplete', 'missing', 'not enough'],
            'complex_scenarios': ['complex', 'international', 'multi-jurisdiction'],
            'response_time': ['slow', 'delay', 'waiting']
        }
        
        for theme, keywords in common_issues.items():
            # Count feedback containing theme keywords
            count = len(df[df['comment'].str.contains('|'.join(keywords), case=False, na=False)])
            if count > 0:
                themes.append({
                    'theme': theme,
                    'frequency': count,
                    'keywords': keywords
                })
        
        return themes
    
    def _identify_accuracy_issues(self, feedback_data: List[Dict]) -> List[Dict]:
        """
        Identify accuracy issues from feedback data.
        
        Args:
            feedback_data (List[Dict]): List of user feedback records
            
        Returns:
            List[Dict]: Accuracy issues found
        """
        issues = []
        
        # Filter for feedback indicating accuracy problems
        accuracy_feedback = [f for f in feedback_data if 
                           any(keyword in f.get('comment', '').lower() for keyword in 
                               ['wrong', 'incorrect', 'error', 'mistake'])]
        
        for feedback in accuracy_feedback:
            issues.append({
                'feedback_id': feedback.get('id'),
                'issue_type': 'accuracy_problem',
                'description': feedback.get('comment', '')[:100],
                'timestamp': feedback.get('timestamp')
            })
        
        return issues
    
    def _generate_improvement_actions(self, themes: List[Dict], issues: List[Dict]) -> List[Dict]:
        """
        Generate improvement actions based on feedback analysis.
        
        Args:
            themes (List[Dict]): Identified feedback themes
            issues (List[Dict]): Identified accuracy issues
            
        Returns:
            List[Dict]: Suggested improvement actions
        """
        actions = []
        
        # Prioritize actions based on frequency and severity
        for theme in themes:
            if theme['theme'] == 'calculation_errors':
                actions.append({
                    'priority': 'high',
                    'action': 'Review calculation validation logic',
                    'description': f'Found {theme["frequency"]} instances of calculation errors'
                })
            elif theme['theme'] == 'incomplete_answers':
                actions.append({
                    'priority': 'medium',
                    'action': 'Enhance response completeness checks',
                    'description': f'Found {theme["frequency"]} instances of incomplete answers'
                })
            elif theme['theme'] == 'complex_scenarios':
                actions.append({
                    'priority': 'medium',
                    'action': 'Improve expert review flagging for complex cases',
                    'description': f'Found {theme["frequency"]} instances of complex scenario issues'
                })
        
        # Add actions for specific accuracy issues
        if len(issues) > 5:  # If we have more than 5 accuracy issues
            actions.append({
                'priority': 'high',
                'action': 'Initiate model retraining pipeline',
                'description': f'Found {len(issues)} accuracy issues requiring model updates'
            })
        
        return actions
    
    def check_model_performance(self) -> Dict:
        """
        Check current model performance and determine if retraining is needed.
        
        Returns:
            Dict: Performance check results
        """
        logger.info("Checking model performance...")
        
        # Get accuracy report
        report = self.validator.get_accuracy_report()
        current_accuracy = report.get('accuracy_rate', 0)
        
        # Determine if retraining is needed
        needs_retraining = current_accuracy < self.retraining_threshold
        
        performance_check = {
            'current_accuracy': current_accuracy,
            'threshold': self.retraining_threshold,
            'needs_retraining': needs_retraining,
            'details': report
        }
        
        if needs_retraining:
            logger.warning(f"Model accuracy {current_accuracy:.2%} below threshold {self.retraining_threshold:.2%}")
        else:
            logger.info(f"Model accuracy {current_accuracy:.2%} meets threshold")
        
        return performance_check
    
    def initiate_retraining(self, training_data: Dict) -> Dict:
        """
        Initiate model retraining process.
        
        Args:
            training_data (Dict): Updated training data
            
        Returns:
            Dict: Retraining process status
        """
        logger.info("Initiating model retraining...")
        
        # In a real implementation, this would trigger actual model retraining
        # For this example, we'll simulate the process
        retraining_status = {
            'status': 'initiated',
            'timestamp': datetime.utcnow().isoformat(),
            'models_to_retrain': ['qa_model', 'calculation_model'],
            'estimated_completion_time': '2 hours',
            'data_points': len(training_data.get('qa_pairs', []))
        }
        
        self.improvement_log.append({
            'timestamp': datetime.utcnow().isoformat(),
            'retraining_initiated': retraining_status
        })
        
        logger.info(f"Model retraining initiated for {len(retraining_status['models_to_retrain'])} models")
        return retraining_status
    
    def get_improvement_log(self) -> List[Dict]:
        """
        Get the continuous improvement log.
        
        Returns:
            List[Dict]: Improvement log entries
        """
        return self.improvement_log
    
    def generate_improvement_report(self) -> Dict:
        """
        Generate a comprehensive improvement report.
        
        Returns:
            Dict: Improvement report
        """
        logger.info("Generating improvement report...")
        
        # Get recent improvement log entries
        recent_entries = [entry for entry in self.improvement_log 
                         if datetime.fromisoformat(entry['timestamp']) > 
                         datetime.utcnow() - timedelta(days=self.feedback_window)]
        
        # Aggregate feedback metrics
        feedback_metrics = [entry.get('analysis', {}).get('feedback_metrics', {}) 
                          for entry in recent_entries if 'analysis' in entry]
        
        # Aggregate improvement opportunities
        improvement_opportunities = [entry.get('analysis', {}).get('improvement_opportunities', {}) 
                                   for entry in recent_entries if 'analysis' in entry]
        
        report = {
            'report_period': f"Last {self.feedback_window} days",
            'timestamp': datetime.utcnow().isoformat(),
            'feedback_summary': self._aggregate_feedback_metrics(feedback_metrics),
            'improvement_opportunities': improvement_opportunities,
            'recommended_actions': self._consolidate_actions(improvement_opportunities)
        }
        
        logger.info("Improvement report generated")
        return report
    
    def _aggregate_feedback_metrics(self, metrics_list: List[Dict]) -> Dict:
        """
        Aggregate feedback metrics from multiple entries.
        
        Args:
            metrics_list (List[Dict]): List of feedback metrics
            
        Returns:
            Dict: Aggregated metrics
        """
        if not metrics_list:
            return {}
        
        total_feedback = sum(m.get('total_feedback', 0) for m in metrics_list)
        avg_positive_ratio = sum(m.get('positive_feedback_ratio', 0) for m in metrics_list) / len(metrics_list)
        avg_negative_ratio = sum(m.get('negative_feedback_ratio', 0) for m in metrics_list) / len(metrics_list)
        avg_rating = sum(m.get('average_rating', 0) for m in metrics_list) / len(metrics_list)
        
        return {
            'total_feedback_analyzed': total_feedback,
            'average_positive_feedback_ratio': avg_positive_ratio,
            'average_negative_feedback_ratio': avg_negative_ratio,
            'overall_average_rating': avg_rating
        }
    
    def _consolidate_actions(self, opportunities_list: List[Dict]) -> List[Dict]:
        """
        Consolidate improvement actions from multiple opportunities.
        
        Args:
            opportunities_list (List[Dict]): List of improvement opportunities
            
        Returns:
            List[Dict]: Consolidated actions
        """
        actions = []
        
        # Extract actions from each opportunity set
        for opportunities in opportunities_list:
            suggested_actions = opportunities.get('suggested_actions', [])
            actions.extend(suggested_actions)
        
        # Deduplicate and prioritize actions
        action_descriptions = set()
        unique_actions = []
        
        for action in actions:
            description = action.get('description', '')
            if description not in action_descriptions:
                action_descriptions.add(description)
                unique_actions.append(action)
        
        # Sort by priority (high, medium, low)
        priority_order = {'high': 0, 'medium': 1, 'low': 2}
        unique_actions.sort(key=lambda x: priority_order.get(x.get('priority', 'low'), 3))
        
        return unique_actions

# Example usage
if __name__ == "__main__":
    ci = ContinuousImprovement()
    
    # Sample feedback data
    sample_feedback = [
        {
            'id': 'fb001',
            'user_id': 'user123',
            'rating': 5,
            'comment': 'Great tax advice, very accurate calculations',
            'timestamp': datetime.utcnow().isoformat()
        },
        {
            'id': 'fb002',
            'user_id': 'user456',
            'rating': 2,
            'comment': 'Incorrect calculation for my corporate tax',
            'timestamp': datetime.utcnow().isoformat()
        },
        {
            'id': 'fb003',
            'user_id': 'user789',
            'rating': 3,
            'comment': 'Response was incomplete, missing some details',
            'timestamp': datetime.utcnow().isoformat()
        }
    ]
    
    # Analyze feedback
    analysis = ci.analyze_feedback(sample_feedback)
    print(json.dumps(analysis, indent=2))
    
    # Check model performance
    performance = ci.check_model_performance()
    print(json.dumps(performance, indent=2))