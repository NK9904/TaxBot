import logging
import logging.config
import json
from datetime import datetime

def setup_logging():
    """Set up logging configuration for the TaxBot system."""
    logging_config = {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'standard': {
                'format': '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
            },
            'detailed': {
                'format': '%(asctime)s [%(levelname)s] %(name)s:%(lineno)d: %(message)s'
            }
        },
        'handlers': {
            'console': {
                'level': 'INFO',
                'class': 'logging.StreamHandler',
                'formatter': 'standard'
            },
            'file': {
                'level': 'DEBUG',
                'class': 'logging.FileHandler',
                'filename': 'logs/taxbot.log',
                'formatter': 'detailed'
            },
            'error_file': {
                'level': 'ERROR',
                'class': 'logging.FileHandler',
                'filename': 'logs/errors.log',
                'formatter': 'detailed'
            }
        },
        'loggers': {
            '': {
                'handlers': ['console', 'file', 'error_file'],
                'level': 'DEBUG',
                'propagate': False
            },
            'taxbot': {
                'handlers': ['console', 'file', 'error_file'],
                'level': 'DEBUG',
                'propagate': False
            }
        }
    }
    
    # Create logs directory if it doesn't exist
    import os
    if not os.path.exists('logs'):
        os.makedirs('logs')
    
    logging.config.dictConfig(logging_config)
    return logging.getLogger('taxbot')

def log_accuracy_validation(validation_result: dict, query: str):
    """Log accuracy validation results."""
    logger = logging.getLogger('taxbot.validation')
    if validation_result.get('is_valid'):
        logger.info(f"Valid response for query: {query[:50]}...")
    else:
        logger.warning(f"Invalid response for query: {query[:50]}... - Corrections needed: {len(validation_result.get('corrections_needed', []))}")

def log_model_performance(model_name: str, accuracy: float, threshold: float = 0.95):
    """Log model performance metrics."""
    logger = logging.getLogger('taxbot.models')
    if accuracy >= threshold:
        logger.info(f"Model {model_name} performance: {accuracy:.2f} (above threshold)")
    else:
        logger.warning(f"Model {model_name} performance: {accuracy:.2f} (below threshold)")

def log_user_interaction(user_id: str, query: str, response: dict):
    """Log user interactions for monitoring and improvement."""
    logger = logging.getLogger('taxbot.interactions')
    logger.info(f"User {user_id} query: {query[:50]}... - Response confidence: {response.get('confidence_score', 'N/A')}")