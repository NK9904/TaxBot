"""
Configuration module for TaxBot v2.0.
This module contains all configuration parameters for the system.
"""

import os
from typing import Dict, Any

class Config:
    """Configuration class for TaxBot system."""
    
    # Model configuration
    BASE_MODEL = os.getenv('BASE_MODEL', 'microsoft/deberta-v3-large')
    ACCURACY_THRESHOLD = float(os.getenv('ACCURACY_THRESHOLD', '0.95'))
    
    # API configuration
    API_HOST = os.getenv('API_HOST', '0.0.0.0')
    API_PORT = int(os.getenv('API_PORT', '8000'))
    
    # Data configuration
    DATA_DIR = os.getenv('DATA_DIR', 'data')
    MODELS_DIR = os.getenv('MODELS_DIR', 'models')
    LOGS_DIR = os.getenv('LOGS_DIR', 'logs')
    
    # Subscription configuration
    DEFAULT_SUBSCRIPTION_LIMIT = int(os.getenv('DEFAULT_SUBSCRIPTION_LIMIT', '100'))
    PREMIUM_SUBSCRIPTION_LIMIT = int(os.getenv('PREMIUM_SUBSCRIPTION_LIMIT', '1000'))
    
    # Validation configuration
    ERROR_THRESHOLD = float(os.getenv('ERROR_THRESHOLD', '0.05'))
    
    # Jurisdiction configuration
    SUPPORTED_JURISDICTIONS = ['US', 'CA']
    SUPPORTED_TAX_TYPES = ['corporate', 'personal', 'cross_border']
    
    @classmethod
    def get_model_config(cls) -> Dict[str, Any]:
        """Get model configuration parameters."""
        return {
            'base_model': cls.BASE_MODEL,
            'accuracy_threshold': cls.ACCURACY_THRESHOLD
        }
    
    @classmethod
    def get_api_config(cls) -> Dict[str, Any]:
        """Get API configuration parameters."""
        return {
            'host': cls.API_HOST,
            'port': cls.API_PORT
        }
    
    @classmethod
    def get_data_config(cls) -> Dict[str, Any]:
        """Get data configuration parameters."""
        return {
            'data_dir': cls.DATA_DIR,
            'models_dir': cls.MODELS_DIR,
            'logs_dir': cls.LOGS_DIR
        }
    
    @classmethod
    def get_subscription_config(cls) -> Dict[str, Any]:
        """Get subscription configuration parameters."""
        return {
            'default_limit': cls.DEFAULT_SUBSCRIPTION_LIMIT,
            'premium_limit': cls.PREMIUM_SUBSCRIPTION_LIMIT
        }

# Create a global config instance
config = Config()