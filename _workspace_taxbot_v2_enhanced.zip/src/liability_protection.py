from typing import Dict, List
import json
from datetime import datetime

class LiabilityProtection:
    """
    Comprehensive liability protection system
    """
    
    def __init__(self):
        self.confidence_thresholds = {
            'high_risk': 0.99,  # Tax court matters
            'medium_risk': 0.95,  # Complex calculations
            'low_risk': 0.90   # General guidance
        }
    
    def assess_liability_risk(self, query: str, response: dict) -> dict:
        """
        Assesses liability risk for each response
        """
        risk_factors = {
            'query_complexity': self.analyze_query_complexity(query),
            'financial_impact': self.estimate_financial_impact(response),
            'regulatory_sensitivity': self.check_regulatory_sensitivity(query),
            'precedent_availability': self.check_precedent_strength(response)
        }
        
        overall_risk = self.calculate_overall_risk(risk_factors)
        risk_level = self.determine_risk_level(overall_risk)
        
        return {
            'risk_level': risk_level,
            'required_disclaimers': self.get_required_disclaimers(overall_risk),
            'professional_review_required': overall_risk > 0.7,
            'insurance_coverage': self.check_insurance_coverage(overall_risk)
        }
    
    def analyze_query_complexity(self, query: str) -> float:
        """
        Analyze the complexity of the query
        """
        # Simple heuristic for complexity
        complex_keywords = ['multi-jurisdictional', 'international', 'complex', 'audit', 'penalty']
        complexity_score = 0
        
        for keyword in complex_keywords:
            if keyword in query.lower():
                complexity_score += 0.2
        
        return min(1.0, complexity_score)
    
    def estimate_financial_impact(self, response: dict) -> float:
        """
        Estimate financial impact of the advice
        """
        # If response contains calculations with large amounts, higher risk
        if 'calculations' in response:
            for calc in response['calculations'].values():
                if isinstance(calc.get('result'), (int, float)) and calc['result'] > 100000:
                    return 0.9  # High risk
        
        return 0.5  # Medium risk
    
    def check_regulatory_sensitivity(self, query: str) -> float:
        """
        Check if query involves sensitive regulatory areas
        """
        sensitive_areas = ['audit', 'penalty', 'criminal', 'fraud', 'dispute']
        sensitivity_score = 0
        
        for area in sensitive_areas:
            if area in query.lower():
                sensitivity_score += 0.25
        
        return min(1.0, sensitivity_score)
    
    def check_precedent_strength(self, response: dict) -> float:
        """
        Check the strength of precedents cited in response
        """
        if 'citations' not in response:
            return 0.8  # Weak precedent strength
        
        # If citations are from tax court or similar, stronger precedent
        strong_precedent_keywords = ['tax court', 'court decision', 'legal precedent']
        precedent_strength = 0.5  # Default medium strength
        
        for citation in response['citations']:
            for keyword in strong_precedent_keywords:
                if keyword in citation.lower():
                    precedent_strength += 0.25
        
        return min(1.0, precedent_strength)
    
    def calculate_overall_risk(self, risk_factors: dict) -> float:
        """
        Calculate overall risk score
        """
        # Weighted average
        weights = {
            'query_complexity': 0.25,
            'financial_impact': 0.3,
            'regulatory_sensitivity': 0.3,
            'precedent_availability': 0.15
        }
        
        total_risk = 0
        for factor, score in risk_factors.items():
            total_risk += score * weights.get(factor, 0)
        
        return total_risk
    
    def determine_risk_level(self, overall_risk: float) -> str:
        """
        Determine risk level based on overall score
        """
        if overall_risk > 0.8:
            return 'HIGH'
        elif overall_risk > 0.6:
            return 'MEDIUM'
        else:
            return 'LOW'
    
    def get_required_disclaimers(self, overall_risk: float) -> List[str]:
        """
        Get required disclaimers based on risk level
        """
        disclaimers = [
            "This advice is provided by an AI system and should not be considered a substitute for professional tax advice."
        ]
        
        if overall_risk > 0.7:
            disclaimers.append(
                "Due to the complexity of this query, we strongly recommend consulting with a qualified tax professional."
            )
        
        if overall_risk > 0.9:
            disclaimers.append(
                "This advice involves high-risk areas. Professional verification is essential before implementation."
            )
        
        return disclaimers
    
    def check_insurance_coverage(self, overall_risk: float) -> bool:
        """
        Check if response falls under insurance coverage
        """
        # Placeholder - would integrate with actual insurance policies
        return overall_risk < 0.9