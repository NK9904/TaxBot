import torch
from transformers import (
    AutoTokenizer, 
    AutoModelForQuestionAnswering,
    AutoModelForSequenceClassification,
    Trainer, 
    TrainingArguments
)
from datasets import Dataset, DatasetDict
import numpy as np
from sklearn.model_selection import train_test_split

class TaxModelTrainer:
    """
    Fine-tunes LLMs on scraped tax code data with accuracy focus
    """
    
    def __init__(self, base_model='microsoft/deberta-v3-large'):
        self.base_model = base_model
        self.tokenizer = AutoTokenizer.from_pretrained(base_model)
        self.models = {
            'qa_model': None,
            'classification_model': None,
            'calculation_model': None,
            'fraud_detection_model': None
        }
        self.accuracy_threshold = 0.95  # 95% accuracy requirement
    
    def prepare_training_data(self, scraped_data):
        """
        Converts scraped tax code into training datasets
        """
        datasets = {
            'qa_pairs': self.generate_qa_pairs(scraped_data),
            'classification': self.generate_classification_data(scraped_data),
            'calculations': self.generate_calculation_examples(scraped_data),
            'fraud_patterns': self.generate_fraud_patterns(scraped_data)
        }
        
        # Add synthetic edge cases
        datasets['edge_cases'] = self.generate_edge_cases()
        
        # Validate data quality
        for dataset_name, data in datasets.items():
            quality_score = self.validate_data_quality(data)
            if quality_score < 0.9:
                print(f"Warning: {dataset_name} quality score: {quality_score}")
        
        return datasets
    
    def generate_qa_pairs(self, scraped_data):
        """
        Creates question-answer pairs from tax code
        """
        qa_pairs = []
        
        # Extract provisions and create Q&A
        for section in scraped_data.get('corporate_tax', {}).get('us', {}).get('federal', []):
            if 'content' in section:
                # Generate multiple question variants
                questions = self.generate_question_variants(section['title'], section['content'])
                for question in questions:
                    qa_pairs.append({
                        'question': question['text'],
                        'context': ' '.join(section['content']),
                        'answer': question['answer'],
                        'confidence': question['confidence'],
                        'source': section.get('source', 'IRS Code'),
                        'section_ref': section.get('title', '')
                    })
        
        return qa_pairs
    
    def train_models(self, datasets):
        """
        Trains all specialized models with accuracy validation
        """
        training_results = {}
        
        # 1. Train Q&A Model
        print("Training Q&A Model...")
        qa_model = self.train_qa_model(datasets['qa_pairs'])
        qa_accuracy = self.evaluate_model_accuracy(qa_model, datasets['qa_pairs'])
        
        if qa_accuracy < self.accuracy_threshold:
            print(f"Q&A Model accuracy {qa_accuracy} below threshold. Retraining...")
            qa_model = self.retrain_with_augmentation(qa_model, datasets['qa_pairs'])
        
        training_results['qa'] = {'model': qa_model, 'accuracy': qa_accuracy}
        
        # 2. Train Classification Model
        print("Training Classification Model...")
        class_model = self.train_classification_model(datasets['classification'])
        class_accuracy = self.evaluate_model_accuracy(class_model, datasets['classification'])
        training_results['classification'] = {'model': class_model, 'accuracy': class_accuracy}
        
        # 3. Train Calculation Verification Model
        print("Training Calculation Model...")
        calc_model = self.train_calculation_model(datasets['calculations'])
        calc_accuracy = self.evaluate_calculation_accuracy(calc_model, datasets['calculations'])
        training_results['calculation'] = {'model': calc_model, 'accuracy': calc_accuracy}
        
        # 4. Train Fraud Detection Model
        print("Training Fraud Detection Model...")
        fraud_model = self.train_fraud_model(datasets['fraud_patterns'])
        fraud_accuracy = self.evaluate_fraud_detection(fraud_model, datasets['fraud_patterns'])
        training_results['fraud'] = {'model': fraud_model, 'accuracy': fraud_accuracy}
        
        return training_results
    
    def train_qa_model(self, qa_data):
        """
        Fine-tunes model for tax Q&A
        """
        model = AutoModelForQuestionAnswering.from_pretrained(self.base_model)
        
        # Prepare dataset
        train_data, val_data = train_test_split(qa_data, test_size=0.2, random_state=42)
        
        train_dataset = Dataset.from_list(train_data)
        val_dataset = Dataset.from_list(val_data)
        
        # Tokenize
        def tokenize_function(examples):
            return self.tokenizer(
                examples["question"],
                examples["context"],
                truncation=True,
                padding="max_length",
                max_length=512
            )
        
        tokenized_train = train_dataset.map(tokenize_function, batched=True)
        tokenized_val = val_dataset.map(tokenize_function, batched=True)
        
        # Training arguments with accuracy focus
        training_args = TrainingArguments(
            output_dir="./tax_qa_model",
            evaluation_strategy="steps",
            eval_steps=100,
            learning_rate=2e-5,
            per_device_train_batch_size=8,
            per_device_eval_batch_size=8,
            num_train_epochs=10,  # More epochs for accuracy
            weight_decay=0.01,
            warmup_steps=500,
            logging_dir="./logs",
            save_strategy="best",
            load_best_model_at_end=True,
            metric_for_best_model="eval_loss",
            greater_is_better=False,
            fp16=True,  # Mixed precision for efficiency
            gradient_checkpointing=True,
            gradient_accumulation_steps=4
        )
        
        trainer = Trainer(
            model=model,
            args=training_args,
            train_dataset=tokenized_train,
            eval_dataset=tokenized_val,
            tokenizer=self.tokenizer,
            compute_metrics=self.compute_qa_metrics
        )
        
        trainer.train()
        
        return model
    
    def compute_qa_metrics(self, eval_pred):
        """
        Custom metrics for Q&A accuracy
        """
        predictions, labels = eval_pred
        
        # Extract answer spans
        start_positions = predictions[0]
        end_positions = predictions[1]
        
        # Calculate exact match and F1 scores
        exact_match = 0
        f1_total = 0
        
        for i in range(len(start_positions)):
            pred_start = np.argmax(start_positions[i])
            pred_end = np.argmax(end_positions[i])
            
            true_start = labels[0][i]
            true_end = labels[1][i]
            
            if pred_start == true_start and pred_end == true_end:
                exact_match += 1
            
            # Calculate F1
            pred_tokens = set(range(pred_start, pred_end + 1))
            true_tokens = set(range(true_start, true_end + 1))
            
            if len(pred_tokens) == 0 or len(true_tokens) == 0:
                f1 = 0
            else:
                precision = len(pred_tokens & true_tokens) / len(pred_tokens)
                recall = len(pred_tokens & true_tokens) / len(true_tokens)
                f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
            
            f1_total += f1
        
        return {
            'exact_match': exact_match / len(start_positions),
            'f1': f1_total / len(start_positions)
        }