"""
Production deployment configuration with high availability and accuracy focus
"""

# kubernetes_deployment.yaml
KUBERNETES_CONFIG = """
apiVersion: apps/v1
kind: Deployment
metadata:
  name: taxbot-backend
  namespace: production
spec:
  replicas: 5  # High availability
  selector:
    matchLabels:
      app: taxbot-backend
  template:
    metadata:
      labels:
        app: taxbot-backend
    spec:
      containers:
      - name: api-server
        image: taxbot/backend:v2.0
        ports:
        - containerPort: 8000
        env:
        - name: MODEL_ACCURACY_THRESHOLD
          value: "0.95"
        - name: ENABLE_ACCURACY_MONITORING
          value: "true"
        resources:
          requests:
            memory: "8Gi"
            cpu: "2"
          limits:
            memory: "16Gi"
            cpu: "4"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
      
      - name: model-server
        image: taxbot/model-server:v2.0
        ports:
        - containerPort: 8001
        env:
        - name: LOAD_MODELS
          value: "qa,calculation,fraud,classification"
        resources:
          requests:
            memory: "16Gi"
            cpu: "4"
            nvidia.com/gpu: "1"  # GPU for model inference
          limits:
            memory: "32Gi"
            cpu: "8"
            nvidia.com/gpu: "1"
      
      - name: accuracy-monitor
        image: taxbot/accuracy-monitor:v2.0
        ports:
        - containerPort: 8002
        env:
        - name: MONITORING_INTERVAL
          value: "60"
        - name: ACCURACY_THRESHOLD
          value: "0.95"
        
---
apiVersion: v1
kind: Service
metadata:
  name: taxbot-service
  namespace: production
spec:
  selector:
    app: taxbot-backend
  ports:
    - protocol: TCP
      port: 80
      targetPort: 8000
  type: LoadBalancer
"""

# Database configuration with replication
DATABASE_CONFIG = {
    'primary': {
        'host': 'db-primary.taxbot.internal',
        'port': 5432,
        'database': 'taxbot_prod',
        'pool_size': 50
    },
    'replicas': [
        {
            'host': 'db-replica-1.taxbot.internal',
            'port': 5432,
            'database': 'taxbot_prod'
        },
        {
            'host': 'db-replica-2.taxbot.internal',
            'port': 5432,
            'database': 'taxbot_prod'
        }
    ],
    'cache': {
        'redis_cluster': [
            'redis-1.taxbot.internal:6379',
            'redis-2.taxbot.internal:6379',
            'redis-3.taxbot.internal:6379'
        ]
    }
}

# Model serving configuration
MODEL_SERVING_CONFIG = {
    'inference_endpoints': {
        'qa_model': {
            'endpoint': 'http://model-server:8001/qa',
            'timeout': 5,
            'retries': 3
        },
        'calculation_model': {
            'endpoint': 'http://model-server:8001/calculate',
            'timeout': 3,
            'retries': 2
        },
        'fraud_model': {
            'endpoint': 'http://model-server:8001/fraud',
            'timeout': 10,
            'retries': 2
        }
    },
    'fallback_models': {
        'primary': 'gpt-4',
        'secondary': 'claude-3'
    }
}