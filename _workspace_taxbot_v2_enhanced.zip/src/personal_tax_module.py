from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, List, Optional
import json

class PersonalTaxEngine:
    """
    Handles personal income tax calculations for US and Canadian individuals
    """
    
    def __init__(self):
        self.load_tax_tables()
        self.deduction_rules = self.load_deduction_rules()
        self.credit_calculator = TaxCreditCalculator()
    
    def load_tax_tables(self):
        """
        Loads current year tax brackets and rates
        """
        self.us_tax_brackets_2025 = {
            'single': [
                (11600, 0.10),    # $0 to $11,600
                (47150, 0.12),    # $11,601 to $47,150
                (100525, 0.22),   # $47,151 to $100,525
                (191950, 0.24),   # $100,526 to $191,950
                (243725, 0.32),   # $191,951 to $243,725
                (609350, 0.35),   # $243,726 to $609,350
                (float('inf'), 0.37)  # $609,351+
            ],
            'married_joint': [
                (23200, 0.10),
                (94300, 0.12),
                (201050, 0.22),
                (383900, 0.24),
                (487450, 0.32),
                (731200, 0.35),
                (float('inf'), 0.37)
            ]
        }
        
        self.canadian_tax_brackets_2025 = {
            'federal': [
                (53359, 0.15),
                (106717, 0.205),
                (165430, 0.26),
                (235675, 0.29),
                (float('inf'), 0.33)
            ]
        }
    
    def calculate_personal_tax(self, taxpayer_data: dict) -> dict:
        """
        Comprehensive personal tax calculation
        """
        jurisdiction = taxpayer_data['jurisdiction']
        
        if jurisdiction == 'US':
            return self.calculate_us_personal_tax(taxpayer_data)
        elif jurisdiction == 'CA':
            return self.calculate_canadian_personal_tax(taxpayer_data)
        else:
            return {'error': 'Unsupported jurisdiction'}
    
    def calculate_us_personal_tax(self, data: dict) -> dict:
        """
        US personal income tax calculation with all deductions and credits
        """
        # Gross income
        gross_income = Decimal(str(data['wages'])) + \
                      Decimal(str(data.get('interest', 0))) + \
                      Decimal(str(data.get('dividends', 0))) + \
                      Decimal(str(data.get('capital_gains', 0))) + \
                      Decimal(str(data.get('business_income', 0)))
        
        # Adjustments (Above-the-line deductions)
        adjustments = self.calculate_adjustments(data)
        agi = gross_income - adjustments
        
        # Standard or itemized deductions
        if data.get('itemize_deductions', False):
            deductions = self.calculate_itemized_deductions(data)
        else:
            deductions = self.get_standard_deduction(data['filing_status'])
        
        # QBI deduction for business income
        qbi_deduction = self.calculate_qbi_deduction(data, agi)
        
        taxable_income = max(Decimal('0'), agi - deductions - qbi_deduction)
        
        # Calculate tax
        federal_tax = self.calculate_us_federal_tax(
            taxable_income, 
            data['filing_status']
        )
        
        # Apply credits
        credits = self.calculate_tax_credits(data)
        federal_tax_after_credits = max(Decimal('0'), federal_tax - credits['total'])
        
        # State tax
        state_tax = self.calculate_state_tax(data, agi)
        
        # Additional taxes
        amt = self.calculate_amt(data, agi)
        net_investment_tax = self.calculate_niit(data, agi)
        additional_medicare = self.calculate_additional_medicare(data)
        
        total_tax = federal_tax_after_credits + state_tax + amt + \
                   net_investment_tax + additional_medicare
        
        return {
            'gross_income': float(gross_income),
            'adjusted_gross_income': float(agi),
            'taxable_income': float(taxable_income),
            'federal_tax': float(federal_tax),
            'credits_applied': credits,
            'federal_tax_after_credits': float(federal_tax_after_credits),
            'state_tax': float(state_tax),
            'alternative_minimum_tax': float(amt),
            'net_investment_income_tax': float(net_investment_tax),
            'additional_medicare_tax': float(additional_medicare),
            'total_tax': float(total_tax),
            'effective_rate': float(total_tax / gross_income) if gross_income > 0 else 0,
            'marginal_rate': self.get_marginal_rate(taxable_income, data['filing_status']),
            'tax_savings_opportunities': self.identify_personal_tax_savings(data)
        }
    
    def calculate_canadian_personal_tax(self, data: dict) -> dict:
        """
        Canadian personal income tax calculation
        """
        # Total income
        total_income = Decimal(str(data['employment_income'])) + \
                      Decimal(str(data.get('investment_income', 0))) + \
                      Decimal(str(data.get('capital_gains', 0))) * Decimal('0.5') + \
                      Decimal(str(data.get('eligible_dividends', 0))) * Decimal('1.38') + \
                      Decimal(str(data.get('other_income', 0)))
        
        # Deductions
        rrsp_deduction = Decimal(str(data.get('rrsp_contribution', 0)))
        union_dues = Decimal(str(data.get('union_dues', 0)))
        child_care = Decimal(str(data.get('child_care_expenses', 0)))
        
        net_income = total_income - rrsp_deduction - union_dues - child_care
        
        # Calculate taxable income
        taxable_income = net_income - Decimal(str(data.get('other_deductions', 0)))
        
        # Federal tax
        federal_tax = self.calculate_canadian_federal_tax(taxable_income)
        
        # Federal credits
        basic_personal_amount = Decimal('15000')
        federal_credits = basic_personal_amount * Decimal('0.15')
        
        # Additional credits
        if data.get('eligible_dependents'):
            federal_credits += Decimal('2350') * Decimal('0.15')
        
        federal_tax_payable = max(Decimal('0'), federal_tax - federal_credits)
        
        # Provincial tax
        provincial_tax = self.calculate_provincial_tax_personal(
            taxable_income, 
            data['province']
        )
        
        # CPP and EI
        cpp = min(Decimal(str(data['employment_income'])) * Decimal('0.0595'), 
                  Decimal('3754.45'))
        ei = min(Decimal(str(data['employment_income'])) * Decimal('0.0163'), 
                 Decimal('1002.45'))
        
        total_tax = federal_tax_payable + provincial_tax + cpp + ei
        
        return {
            'total_income': float(total_income),
            'net_income': float(net_income),
            'taxable_income': float(taxable_income),
            'federal_tax': float(federal_tax),
            'federal_credits': float(federal_credits),
            'federal_tax_payable': float(federal_tax_payable),
            'provincial_tax': float(provincial_tax),
            'cpp_contributions': float(cpp),
            'ei_premiums': float(ei),
            'total_tax_and_deductions': float(total_tax),
            'after_tax_income': float(total_income - total_tax),
            'effective_rate': float(total_tax / total_income) if total_income > 0 else 0,
            'marginal_rate': self.get_canadian_marginal_rate(taxable_income, data['province']),
            'tfsa_contribution_room': self.calculate_tfsa_room(data),
            'rrsp_contribution_room': self.calculate_rrsp_room(data)
        }