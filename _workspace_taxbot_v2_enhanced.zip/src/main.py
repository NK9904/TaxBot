#!/usr/bin/env python3
"""
Main entry point for TaxBot v2.0 application.
This script initializes and runs the TaxBot system.
"""

import argparse
import logging
import sys
import os
from datetime import datetime

# Add src directory to Python path
sys.path.append(os.path.join(os.path.dirname(__file__), '.'))

from config.logging_config import setup_logging
from data.tax_code_scraper import TaxCodeScraper
from models.model_training import TaxModelTrainer
from utils.accuracy_validation import AccuracyValidator
from personal_tax_module import PersonalTaxEngine
from regulatory_compliance import RegulatoryCompliance
from fraud_detection_system import FraudDetectionSystem
from liability_protection import LiabilityProtection
from subscription_management import SubscriptionManager
from api.taxbot_api import app
import uvicorn

def setup_environment():
    """Set up the application environment."""
    # Create necessary directories
    directories = ['logs', 'data', 'models']
    for directory in directories:
        if not os.path.exists(directory):
            os.makedirs(directory)
    
    # Set up logging
    logger = setup_logging()
    logger.info("TaxBot v2.0 environment setup completed")
    return logger

def scrape_tax_data():
    """Scrape tax data from official sources."""
    logger = logging.getLogger('taxbot')
    logger.info("Starting tax code scraping process...")
    
    scraper = TaxCodeScraper()
    scraped_data = asyncio.run(scraper.scrape_all_sources())
    
    logger.info("Tax code scraping process completed")
    return scraped_data

def train_models(scraped_data):
    """Train all models using scraped data."""
    logger = logging.getLogger('taxbot')
    logger.info("Starting model training process...")
    
    trainer = TaxModelTrainer()
    training_data = trainer.prepare_training_data(scraped_data)
    trainer.train_all_models(training_data)
    trainer.save_models()
    
    logger.info("Model training process completed")
    return trainer

def run_api_server():
    """Run the FastAPI server."""
    logger = logging.getLogger('taxbot')
    logger.info("Starting TaxBot API server...")
    
    uvicorn.run("api.taxbot_api:app", host="0.0.0.0", port=8000, reload=True)

async def main():
    """Main function to run the TaxBot system."""
    # Set up argument parser
    parser = argparse.ArgumentParser(description="TaxBot v2.0 - AI-powered tax advisory system")
    parser.add_argument("--scrape", action="store_true", help="Scrape tax data from official sources")
    parser.add_argument("--train", action="store_true", help="Train models on scraped data")
    parser.add_argument("--serve", action="store_true", help="Run API server")
    parser.add_argument("--all", action="store_true", help="Run all processes")
    
    args = parser.parse_args()
    
    # Set up environment
    logger = setup_environment()
    
    # If no arguments provided, show help
    if not any([args.scrape, args.train, args.serve, args.all]):
        parser.print_help()
        return
    
    scraped_data = None
    
    # Scrape data if requested
    if args.scrape or args.all:
        scraped_data = scrape_tax_data()
    
    # Train models if requested
    if args.train or args.all:
        if scraped_data is None:
            logger.error("Cannot train models without scraped data. Run --scrape first.")
            return
        trainer = train_models(scraped_data)
    
    # Run API server if requested
    if args.serve or args.all:
        run_api_server()

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())