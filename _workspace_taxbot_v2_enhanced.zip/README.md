# TaxBot v2.0 - Enhanced Corporate & Personal Tax Advisory System

## Overview
TaxBot v2.0 is an advanced AI-powered tax advisory system that provides accurate tax guidance for both corporate and personal taxpayers in US and Canadian jurisdictions. This system implements custom model training on scraped tax code databases with multiple accuracy validation layers.

## Features
- Dual tax coverage (Corporate & Personal) for US/Canada
- Custom model training on current tax codes
- Multi-layer accuracy validation (95%+ target)
- Real-time monitoring and alerts
- Automated continuous improvement
- Comprehensive testing suite
- Production-ready architecture
- Advanced fraud detection
- Tax planning intelligence

## Enhanced Architecture
The improved system is composed of several key modules organized in a clean directory structure:

```
src/
├── api/                 # FastAPI implementation
├── config/              # Configuration files
├── data/                # Data scraping and processing
├── models/              # Model training components
├── tests/               # Comprehensive test suite
└── utils/               # Utility functions including accuracy validation
```

## Getting Started

### Installation
1. Install dependencies: `pip install -r requirements.txt`

### Running the System
The system can be run in different modes:

1. **Scrape tax data**: `python src/main.py --scrape`
2. **Train models**: `python src/main.py --train`
3. **Run API server**: `python src/main.py --serve`
4. **Run all processes**: `python src/main.py --all`

### API Endpoints
- `GET /` - Health check
- `GET /health` - Detailed health status
- `POST /query` - Process tax queries
- `GET /accuracy-report` - Get system accuracy report
- `GET /user/{user_id}/usage` - Get user usage information

## Testing
Run the comprehensive test suite with: `pytest src/tests/test_accuracy.py`

## Key Improvements in v2.0

### 1. Enhanced Code Structure
- Modular directory organization for better maintainability
- Clear separation of concerns between components
- Standardized file naming and organization

### 2. Improved Accuracy Validation
- Five-layer validation system with detailed reporting
- Syntax validation to ensure proper response structure
- Semantic validation to check response meaningfulness
- Calculation verification for mathematical accuracy
- Cross-reference checking against known tax rules
- Expert review flagging for complex scenarios

### 3. Better Error Handling & Logging
- Comprehensive logging configuration
- Structured error handling throughout the codebase
- Detailed audit trails for all operations

### 4. Production-Ready API
- FastAPI implementation with proper endpoints
- Input validation and sanitization
- Rate limiting and subscription management
- Detailed API documentation

### 5. Enhanced Test Coverage
- Unit tests for all validation layers
- Integration tests for key components
- Mock data for consistent testing
- Quality metrics reporting

## System Requirements
- Python 3.8+
- PyTorch and Transformers for ML model training
- BeautifulSoup and aiohttp for web scraping
- Pandas for data processing and analysis
- FastAPI for API framework
- pytest for testing framework